import { useCallback, useRef, useState } from 'react'
import { MotionConfig, motion, useScroll, useSpring, useTransform } from 'framer-motion'
import Header from './components/Header'
import Hero from './components/Hero'
import { ComoLeer, ComoLoHacen, EnQueMomento, QuePromueven, Quienes, Sintesis } from './components/Relato'
import Wizard from './components/Wizard'
import Instituciones from './components/Instituciones'
import Drawer from './components/Drawer'
import Method from './components/Method'
import uneBlanco from './assets/une-horizontal-blanco.png'
import uneUiBlanco from './assets/une-ui-blanco.png'
import { LogoInstitucion } from './components/Marcas'
import { FECHA_REFERENCIA, INSTITUCIONES } from './lib/data'
import { UnidadProvider } from './lib/unidad'

// Hilo del relato: una línea punteada que se completa con el scroll; un punto dorado (como las empresas de la
// animación de portada) baja por ella y enciende el nodo de cada sección.
function Hilo({ children }) {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 55%', 'end 55%'] })
  const avance = useSpring(scrollYProgress, { stiffness: 110, damping: 28, restDelta: 0.001 })
  const y = useTransform(avance, (v) => `${v * 100}%`)
  return (
    <div className="pf-relato" ref={ref}>
      <div className="pf-hilo" aria-hidden="true">
        <motion.div className="pf-hilo-lleno" style={{ scaleY: avance }} />
        <motion.div className="pf-hilo-carril" style={{ y }}>
          <span className="pf-hilo-punto" />
        </motion.div>
      </div>
      {children}
    </div>
  )
}

// Jerarquía: comprender el sistema → explorar los instrumentos → analizar las instituciones
export default function App() {
  const [abierto, setAbierto] = useState(null)
  const [focoInst, setFocoInst] = useState(null)
  const verInstitucion = useCallback((id) => {
    setFocoInst({ id, t: Date.now() })
    requestAnimationFrame(() => document.getElementById('instituciones')?.scrollIntoView({ behavior: 'smooth' }))
  }, [])
  const cerrar = useCallback(() => setAbierto(null), [])
  return (
    <MotionConfig reducedMotion="user">
      <UnidadProvider>
      <Header />
      <main>
        <Hero onOpen={setAbierto} />
        <Hilo>
          <ComoLeer />
          <Quienes onOpen={setAbierto} />
          <QuePromueven onOpen={setAbierto} />
          <ComoLoHacen onOpen={setAbierto} />
          <EnQueMomento onOpen={setAbierto} />
          <Sintesis />
        </Hilo>
        <Wizard onOpen={setAbierto} />
        <Instituciones onOpen={setAbierto} foco={focoInst} />
        <Method />
      </main>
      <div className="pf-pie-instituciones">
        <div className="pf-contenedor">
          <p>Instituciones relevadas</p>
          <div className="pf-pie-logos">
            {INSTITUCIONES.map((i) => (
              <span key={i.id}><LogoInstitucion id={i.id} escala={0.5} /></span>
            ))}
          </div>
        </div>
      </div>
      <footer className="pf-pie2">
        <div className="pf-contenedor pf-pie2-fila">
          <div className="pf-pie2-une">
            <img src={uneBlanco} alt="UNE · Unidad Nacional de Evaluación del Sistema de Ciencia, Tecnología e Innovación" width="1307" height="164" />
            <p>
              <strong>Portafolio de apoyo empresarial en CTI</strong> es un desarrollo de la Unidad Nacional de Evaluación del Sistema de
              Ciencia, Tecnología e Innovación (UNE-CTI). Reúne y caracteriza los instrumentos públicos de apoyo empresarial en
              Uruguay para explorar la oferta, conocer sus alcances y comprender cómo se apoya el desarrollo empresarial. Fecha de
              referencia: {FECHA_REFERENCIA}. La inclusión en el portafolio no acredita una convocatoria abierta.
            </p>
            <p className="pf-pie2-otros">
              Otro producto de datos de la UNE:{' '}
              <a href="https://gersnano.github.io/cienciaUruguay-pagina/" target="_blank" rel="noopener noreferrer">Ciencia uruguaya</a>
            </p>
          </div>
          <div className="pf-pie2-lado">
            <img src={uneUiBlanco} alt="U+I · UNE" width="183" height="30" />
            <button type="button" className="pf-pie2-arriba" onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })}>
              Volver arriba
            </button>
            <a href="#inicio">Ir a Inicio</a>
          </div>
        </div>
      </footer>
      <Drawer id={abierto} onClose={cerrar} onOpen={setAbierto} />
      </UnidadProvider>
    </MotionConfig>
  )
}
