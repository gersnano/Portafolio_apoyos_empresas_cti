// Cabecera propia del portafolio: una sola barra con la marca UNE, la marca del producto y las tres partes del recorrido.
import { useEffect, useState } from 'react'
import { motion, useScroll, useSpring } from 'framer-motion'
import { LogoUNE, MarcaPortafolio } from './Marcas'

const PARTES = [
  ['comprender', 'Comprender', 'que', ['comprender', 'quienes', 'g1', 'finalidades', 'g2', 'como', 'g3', 'g4', 'momento', 'g5']],
  ['explorar', 'Consulta', 'explorar', ['explorar']],
  ['instituciones', 'Instituciones', 'instituciones', ['instituciones']],
  ['metodologia', 'Notas', 'notas', ['metodologia']],
]
export const PREGUNTAS = [
  ['quienes', 'Quiénes', 'quien', ['quienes', 'g1']],
  ['finalidades', 'Qué', 'que', ['finalidades', 'g2']],
  ['como', 'Cómo', 'como', ['como', 'g3', 'g4']],
  ['momento', 'Cuándo', 'cuando', ['momento', 'g5']],
]

export default function Header() {
  const [activa, setActiva] = useState(null)
  const { scrollYProgress } = useScroll()
  const escala = useSpring(scrollYProgress, { stiffness: 140, damping: 30 })
  useEffect(() => {
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setActiva(e.target.id)), { rootMargin: '-40% 0px -55% 0px' })
    PARTES.flatMap((p) => p[3]).forEach((id) => {
      const el = document.getElementById(id)
      el && io.observe(el)
    })
    const arriba = () => window.scrollY < 400 && setActiva(null)
    window.addEventListener('scroll', arriba, { passive: true })
    return () => {
      io.disconnect()
      window.removeEventListener('scroll', arriba)
    }
  }, [])
  const parte = PARTES.find((p) => p[3].includes(activa))
  return (
    <>
      <header className="pf-cab">
        <div className="pf-contenedor pf-cab-fila">
          <a className="pf-cab-une" href="#inicio" aria-label="UNE · Unidad Nacional de Evaluación del Sistema de Ciencia, Tecnología e Innovación">
            <LogoUNE conNombre={false} />
          </a>
          <span className="pf-cab-sep" aria-hidden="true" />
          <a className="pf-cab-producto" href="#inicio">
            <MarcaPortafolio size={30} />
            <span>
              Portafolio de apoyo
              <small>empresarial en CTI</small>
            </span>
          </a>
          <nav className="pf-cab-nav" aria-label="Partes del recorrido">
            {PARTES.map(([id, n]) => (
              <a key={id} href={`#${id}`} className={parte?.[0] === id ? 'on' : ''} aria-current={parte?.[0] === id ? 'true' : undefined}>
                {parte?.[0] === id && <motion.span layoutId="pf-pastilla" className="pf-pastilla" transition={{ type: 'spring', stiffness: 380, damping: 32 }} />}
                <span>{n}</span>
              </a>
            ))}
          </nav>
        </div>
        <motion.div className="pf-progreso" style={{ scaleX: escala }} aria-hidden="true" />
      </header>
    </>
  )
}
