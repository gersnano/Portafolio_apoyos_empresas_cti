// Ficha del instrumento: estructura fija y lenguaje claro.
import { useEffect, useMemo, useRef } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { ETAPAS, FECHA_REFERENCIA, INST_MAP, INSTR_MAP, STAGES5, perfilDe, similares } from '../lib/data'
import { DIMENSION, VALORES, corto, defFinalidad, defMecanismo, descripcion, uniq } from '../lib/sistema'

const nombreEtapa = (e) => (e === 'transversal' ? 'Transversal' : ETAPAS.find((x) => x.id === e)?.nombre)
const SIN_DATO = <span className="sx-sindato">Sin dato en el relevamiento</span>

function Seccion({ titulo, ayuda, children }) {
  return (
    <section className="fx-sec">
      <h3>
        {titulo}
        {ayuda && <small>{ayuda}</small>}
      </h3>
      {children}
    </section>
  )
}

function Linea({ l, n }) {
  return (
    <article className="fx-linea">
      <h4>
        <span>Línea {n}</span>
        {l.linea}
      </h4>
      <p>{l.descripcion || SIN_DATO}</p>
      <dl>
        <dt>Necesidad</dt>
        <dd>{l.finalidad}</dd>
        <dt>Mecanismo</dt>
        <dd>{l.mecanismo}{l.mecanismosComp?.length ? ` (complementario: ${l.mecanismosComp.join(', ')})` : ''}</dd>
        <dt>Tipo de apoyo</dt>
        <dd>{l.apoyos.length ? l.apoyos.map((a) => a.t).join(' · ') : SIN_DATO}</dd>
        <dt>Etapa</dt>
        <dd>{l.etapas.length ? l.etapas.map(nombreEtapa).join(' · ') : 'Transversal'}{l.transversal ? ` · eje transversal: ${l.transversal}` : ''}</dd>
        <dt>Destinatarios</dt>
        <dd>{l.publico || SIN_DATO}</dd>
        <dt>Fuente oficial</dt>
        <dd className="fx-links">
          {l.urlFicha ? <a href={l.urlFicha} target="_blank" rel="noopener noreferrer">Sitio oficial <Icon name="ext" size={13} /></a> : SIN_DATO}
          {l.urlBases && l.urlBases !== l.urlFicha && <a href={l.urlBases} target="_blank" rel="noopener noreferrer">Bases o documento <Icon name="doc" size={13} /></a>}
        </dd>
      </dl>
    </article>
  )
}

export default function Drawer({ id, onClose, onOpen }) {
  const ins = id ? INSTR_MAP[id] : null
  const closeRef = useRef(null)
  useEffect(() => {
    if (!ins) return
    const prev = document.activeElement
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    setTimeout(() => closeRef.current?.focus(), 50)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
      prev?.focus?.()
    }
  }, [ins, onClose])
  const parecidos = useMemo(() => (ins ? similares(perfilDe(ins), ins.id).slice(0, 4) : []), [ins])
  const inst = ins && INST_MAP[ins.institucion]
  const fins = ins ? VALORES.finalidad(ins) : []
  const mecs = ins ? VALORES.mecanismo(ins) : []
  const apoyos = ins ? VALORES.apoyo(ins) : []
  const destinatarios = ins ? uniq(ins.lineas.map((l) => l.sujeto).filter(Boolean)) : []
  return (
    <AnimatePresence>
      {ins && (
        <>
          <motion.div key="bd" className="backdrop" onClick={onClose} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />
          <motion.aside
            key={ins.id}
            className="drawer fx"
            role="dialog"
            aria-modal="true"
            aria-labelledby="fx-titulo"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 320, damping: 36 }}
          >
            <header className="fx-cab">
              <div>
                <span className="fx-inst">{inst.nombre.startsWith(inst.sigla) ? inst.nombre : `${inst.sigla} · ${inst.nombre}`}</span>
                <h2 id="fx-titulo">{ins.nombre}</h2>
                <span className="fx-meta">
                  {ins.lineas.length > 1 ? `${ins.lineas.length} líneas de apoyo` : '1 línea de apoyo'} · Información con fecha de
                  referencia {FECHA_REFERENCIA}
                </span>
              </div>
              <button ref={closeRef} className="close" onClick={onClose} aria-label="Cerrar ficha">
                <Icon name="x" />
              </button>
            </header>
            <div className="drawer-body fx-cuerpo">
              <Seccion titulo="Descripción">
                <p>{descripcion(ins) || SIN_DATO}</p>
              </Seccion>
              <Seccion titulo="Finalidad" ayuda={DIMENSION.finalidad.def}>
                <ul className="fx-items">
                  {fins.map((f) => (
                    <li key={f}><b>{f}</b><span>{defFinalidad(f)}</span></li>
                  ))}
                </ul>
              </Seccion>
              <Seccion titulo="Mecanismo y tipo de apoyo" ayuda="El mecanismo es cómo se canaliza el apoyo; el tipo de apoyo, qué recibe la empresa.">
                <ul className="fx-items">
                  {mecs.map((m) => (
                    <li key={m}><b>{corto(m)}</b><span>{defMecanismo(m)}</span></li>
                  ))}
                </ul>
                <div className="fx-tags">{apoyos.length ? apoyos.map((a) => <span key={a}>{a}</span>) : SIN_DATO}</div>
              </Seccion>
              <Seccion titulo="Etapas y destinatarios" ayuda={DIMENSION.etapa.def}>
                <div className="fx-etapas">
                  {STAGES5.map((e) => (
                    <span key={e.id} className={ins.etapa === e.id ? 'principal' : ins.cobertura.includes(e.id) ? 'on' : ''}>
                      {e.orden}. {e.nombre}
                    </span>
                  ))}
                  {ins.etapa === 'transversal' && <span className="principal">Transversal</span>}
                </div>
                <p className="fx-ley">
                  <i className="principal" /> etapa principal <i className="on" /> también cubierta por alguna línea
                </p>
                <p><b>Destinatarios:</b> {destinatarios.length ? destinatarios.join(' · ') : SIN_DATO}</p>
              </Seccion>
              <Seccion titulo={ins.lineas.length > 1 ? `Líneas de apoyo (${ins.lineas.length})` : 'Línea de apoyo'} ayuda={ins.lineas.length > 1 ? 'Cada línea tiene sus propias características; el instrumento se cuenta una sola vez.' : undefined}>
                {ins.lineas.map((l, k) => (
                  <Linea key={l.id} l={l} n={k + 1} />
                ))}
              </Seccion>
              {parecidos.length > 0 && (
                <Seccion titulo="Instrumentos parecidos" ayuda="Por cercanía de palabras clave y coincidencia de tipos de apoyo, capacidades, mecanismos y etapas.">
                  <ul className="fx-parecidos">
                    {parecidos.map((r) => (
                      <li key={r.ins.id}>
                        <button onClick={() => onOpen(r.ins.id)}>
                          {r.ins.nombre} <small>{INST_MAP[r.ins.institucion].sigla}</small>
                        </button>
                        <span className="fx-sim"><i style={{ width: `${Math.round(r.sim * 100)}%` }} /></span>
                        <b>{Math.round(r.sim * 100)} %</b>
                      </li>
                    ))}
                  </ul>
                </Seccion>
              )}
              <p className="notice">
                Fecha de actualización: {FECHA_REFERENCIA} (fecha de referencia del relevamiento). La inclusión en el catálogo no
                acredita una convocatoria abierta: requisitos, plazos y montos deben confirmarse en la fuente oficial de {inst.sigla}.
              </p>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  )
}
