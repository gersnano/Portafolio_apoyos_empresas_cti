// Piezas comunes con el tono de los informes de datos de la UNE: capítulos, bloques de gráfico con relato,
// y gráficos de autor (lollipops, matrices de puntos) construidos con d3 y animados con Framer Motion.
import { useRef, useState } from 'react'
import { AnimatePresence, motion, useInView, useReducedMotion } from 'framer-motion'
import { scaleLinear, scaleSqrt } from 'd3-scale'
import Icon from './Icon'
import { Counter, Tabs, ease } from './motion'
import { UNIDADES, useUnidad } from '../lib/unidad'
import { Ico } from './Marcas'
import { INST_MAP } from '../lib/data'
import { FAMILIAS, descargarCSV, pct, plural } from '../lib/sistema'

/* ---------------------------------------------------------------- capítulo */
export function Capitulo({ id, antetitulo, titulo, texto, nota, indice }) {
  return (
    <section className="pf-capitulo" id={id} aria-labelledby={`${id}-t`}>
      {/* nodo del hilo del relato: se enciende al llegar a la sección */}
      <motion.span className="pf-cap-nodo" aria-hidden="true" initial={{ scale: 0.4, opacity: 0.3 }} whileInView={{ scale: 1, opacity: 1 }} viewport={{ margin: '-45% 0px -45% 0px' }} transition={{ type: 'spring', stiffness: 260, damping: 18 }} />
      <motion.div className="pf-contenedor pf-cap-cab" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.6, ease }}>
        {antetitulo && <p className="pf-antetitulo"><span aria-hidden="true" />{antetitulo}</p>}
        <h2 id={`${id}-t`}>{titulo}</h2>
        <p className="pf-cap-texto">{texto}</p>
        {nota && <p className="pf-cap-nota">{nota}</p>}
        {indice?.length > 0 && (
          <nav className="pf-indice" aria-label="Gráficos de la sección">
            {indice.map(([n, t, href]) => (
              <a key={href} href={`#${href}`}>
                <span>Figura {n}</span>
                {t}
              </a>
            ))}
          </nav>
        )}
      </motion.div>
    </section>
  )
}

/** Pictograma de capítulo: pétalos finos sobre un círculo (misma familia gráfica que los gráficos). */
export function Glifo({ petalos = 8, color = '#25408d' }) {
  return (
    <svg width="100" height="100" viewBox="-50 -50 100 100">
      <circle r="47" fill="none" stroke="#c5d0db" />
      {Array.from({ length: petalos }, (_, k) => {
        const a = (360 / petalos) * k
        const L = 18 + ((k * 7) % 4) * 5
        return (
          <g key={k} transform={`rotate(${a})`}>
            <line x1="0" y1="-6" x2="0" y2={-L} stroke={color} strokeWidth="1" />
            <circle cx="0" cy={-L - 3} r={2 + (k % 3)} fill={k % 3 === 0 ? '#f2b705' : 'none'} stroke={color} strokeWidth="1" />
          </g>
        )
      })}
      <circle r="4" fill={color} />
    </svg>
  )
}

/* ---------------------------------------------------------------- bloque de gráfico */
const LECTURA = [
  ['cuenta', 'Qué se cuenta'],
  ['lectura', 'Cómo se lee'],
  ['hallazgo', 'Lo que encontramos'],
]

export function Grafico({ id, num, titulo, bajada, pasos, tabla, csv, nota, children, sinUnidad }) {
  const [verTabla, setVerTabla] = useState(false)
  const U = useUnidad()
  const [copiado, setCopiado] = useState(false)
  const copiar = async () => {
    try {
      await navigator.clipboard.writeText([tabla.cab, ...tabla.filas].map((f) => f.join('\t')).join('\n'))
      setCopiado(true)
      setTimeout(() => setCopiado(false), 1800)
    } catch {
      setCopiado(false)
    }
  }
  return (
    <div className="pf-figura" id={id}>
      <div className="pf-contenedor">
        <motion.header className="pf-fig-cab" initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.55, ease }}>
          <span className="pf-fig-num">Figura {num}</span>
          <div>
            <h3>{titulo}</h3>
            {bajada && <p>{bajada}</p>}
          </div>
          {!sinUnidad && (
            <div className="pf-fig-unidad">
              <span>Contar</span>
              <Tabs id={`u-${id}`} items={UNIDADES} value={U.id} onChange={U.setU} label="Unidad de conteo" />
            </div>
          )}
          {tabla && (
            <div className="pf-fig-acciones">
              <button className="pf-icobtn" aria-pressed={verTabla} onClick={() => setVerTabla((v) => !v)} title={verTabla ? 'Ocultar tabla' : 'Ver tabla'}>
                <Ico n="tabla" size={17} /> <span>{verTabla ? 'Ocultar tabla' : 'Tabla'}</span>
              </button>
              <button className="pf-icobtn" onClick={() => descargarCSV(csv, tabla.cab, tabla.filas)} title="Descargar CSV">
                <Ico n="descargar" size={17} /> <span>CSV</span>
              </button>
              <button className="pf-icobtn" onClick={copiar} title="Copiar datos">
                <Ico n="copiar" size={17} /> <span>{copiado ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>
          )}
        </motion.header>
        <motion.div className="pf-fig-regla" aria-hidden="true" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 1.1, ease }} />
        <motion.div key={U.id} className="pf-fig-area" initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7, ease, delay: 0.15 }}>{children}</motion.div>
        <AnimatePresence initial={false}>
          {verTabla && tabla && (
            <motion.div className="pf-tabla-datos" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.35, ease }}>
              <table>
                <thead>
                  <tr>{tabla.cab.map((c) => <th key={c} scope="col">{c}</th>)}</tr>
                </thead>
                <tbody>
                  {tabla.filas.map((f, i) => (
                    <tr key={i}>{f.map((v, j) => <td key={j} className={typeof v === 'number' ? 'n' : ''}>{v}</td>)}</tr>
                  ))}
                </tbody>
              </table>
            </motion.div>
          )}
        </AnimatePresence>
        <motion.div className="pf-fig-regla" aria-hidden="true" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 1.1, ease }} />
        <div className="pf-lectura">
          {pasos.map((p, i) => (
            <motion.div key={i} className={`pf-lect${i === 2 ? ' clave' : ''}`} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.6, ease, delay: 0.2 + i * 0.18 }}>
              <h4>
                {LECTURA[i][1]}
              </h4>
              <p>{p}</p>
            </motion.div>
          ))}
        </div>
        <p className="pf-fuente">
          Fuente: Portafolio de apoyo empresarial en CTI · UNE-CTI.{nota ? ` ${nota}` : ''}
        </p>
      </div>
    </div>
  )
}

/* ---------------------------------------------------------------- leyenda de familias */
export function Familias({ foco, setFoco, conteo }) {
  return (
    <div className="pf-familias" role="group" aria-label="Familias de mecanismo">
      {FAMILIAS.map((f) => (
        <button
          key={f.id}
          className={foco && foco !== f.id ? 'off' : ''}
          aria-pressed={foco === f.id}
          disabled={!setFoco}
          onClick={() => setFoco?.(foco === f.id ? null : f.id)}
        >
          <i style={{ background: f.c }} />
          {f.n}
          {conteo && <small>{conteo(f)}</small>}
        </button>
      ))}
    </div>
  )
}

/* ---------------------------------------------------------------- lollipops ordenados */
/** Filas ordenadas: tallo fino, cabeza circular (área ∝ cantidad) y, opcionalmente, un punto por instrumento coloreado por familia. */
export function Lollipops({ filas, base, sel, onPick, unidad = 'instrumentos', puntos }) {
  const max = Math.max(...filas.map((f) => f.n), 1)
  const x = scaleLinear().domain([0, max]).range([0, 100])
  const r = scaleSqrt().domain([0, max]).range([3, 11])
  return (
    <div className="cu-lolli" role="list">
      {filas.map((f, k) => {
        const on = sel === f.k
        return (
          <motion.button
            key={f.k}
            role="listitem"
            className={`cu-lolli-fila${puntos ? ' con-puntos' : ''}${on ? ' on' : ''}${sel && !on ? ' off' : ''}`}
            onClick={onPick ? () => onPick(on ? null : f.k) : undefined}
            disabled={!onPick}
            title={f.title}
            aria-pressed={on}
            aria-label={`${f.label}: ${plural(f.n, unidad.replace(/s$/, ''), unidad)}, ${pct(f.n, base)} %`}
            layout="position"
          >
            <span className="cu-lolli-et">
              {f.logo && <span className="pf-lolli-logo">{f.logo}</span>}
              <span>{f.label}</span>
            </span>
            <span className="cu-lolli-pista">
              <svg viewBox="0 0 100 24" preserveAspectRatio="none" aria-hidden="true">
                <line x1="0" x2="100" y1="12" y2="12" className="guia" vectorEffect="non-scaling-stroke" />
                <motion.line
                  x1="0"
                  y1="12"
                  y2="12"
                  className="tallo"
                  vectorEffect="non-scaling-stroke"
                  initial={{ x2: 0 }}
                  whileInView={{ x2: x(f.n) }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, ease, delay: Math.min(k, 12) * 0.04 }}
                />
              </svg>
              <motion.span
                className="cu-lolli-cabeza"
                style={{ width: r(f.n) * 2, height: r(f.n) * 2 }}
                initial={{ left: '0%', scale: 0 }}
                whileInView={{ left: `${x(f.n)}%`, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.9, ease, delay: Math.min(k, 12) * 0.04 }}
              />
            </span>
            <span className="cu-lolli-n">
              <b>{f.n}</b>
              <small>{pct(f.n, base)} %</small>
            </span>
            {puntos && (
                <span className="cu-lolli-puntos" aria-hidden="true">
                  {puntos(f).map((c, j) => (
                    <i key={j} style={{ background: c }} />
                  ))}
                </span>
              )}
          </motion.button>
        )
      })}
    </div>
  )
}

/* ---------------------------------------------------------------- matriz de puntos */
/** Matriz de círculos: el área codifica la cantidad (o el % de la fila). Celdas sin datos: punto hueco mínimo. */
/** Matriz legible: mapa de calor de un solo tono con el número en cada celda. Si las columnas son muchas y de rótulo
 * largo (y las filas, siglas), se traspone para que los rótulos largos queden horizontales. Resalta fila y columna al
 * pasar el cursor, suma totales y fija la primera columna al desplazar en pantallas chicas. */
const RAMPA = ['#e8eef7', '#c6d4ea', '#93acd6', '#5b7cbc', '#2d4f97', '#1a2d66']
export function MatrizPuntos({ filas, cols, celda, modo = 'n', baseFila, sel, onPick, etiquetaFilas, etiquetaCols, trasponer, ordenNatural }) {
  const [hov, setHov] = useState(null) // [fila, columna] bajo el cursor
  const [orden, setOrden] = useState(null) // columna por la que se ordenan las filas
  const ref = useRef(null)
  const visto = useInView(ref, { once: true, margin: '-80px' })
  const reducir = useReducedMotion()
  const largo = (xs) => Math.max(...xs.map((x) => String(x.label).length))
  const tras = trasponer ?? (cols.length > filas.length && largo(filas) <= 12 && largo(cols) > 12)
  const F = tras ? cols : filas
  const Cc = tras ? filas : cols
  const ins = (f, c) => (tras ? celda(c.k, f.k) : celda(f.k, c.k))
  const orig = (f, c) => (tras ? [c.k, f.k] : [f.k, c.k])
  const val = (f, c) => {
    const n = ins(f, c).length
    if (modo !== 'pct') return n
    return pct(n, baseFila(tras ? c.k : f.k))
  }
  const vmax = Math.max(1, ...F.flatMap((f) => Cc.map((c) => val(f, c))))
  const nivel = (v) => (v <= 0 ? -1 : Math.min(RAMPA.length - 1, 1 + Math.floor(((v - 0.001) / vmax) * (RAMPA.length - 1))))
  const unicos = (arrs) => new Set(arrs.flatMap((x) => x.map((i) => i.id))).size
  const totFila = F.map((f) => unicos(Cc.map((c) => ins(f, c))))
  const totCol = Cc.map((c) => unicos(F.map((f) => ins(f, c))))
  const maxTot = Math.max(1, ...totFila)
  const ejeF = tras ? etiquetaCols : etiquetaFilas
  const ejeC = tras ? etiquetaFilas : etiquetaCols
  // orden de las filas: por la columna elegida, o por total cuando la matriz se traspone
  const idx = F.map((f, i) => i)
  if (orden !== null) idx.sort((x, y) => val(F[y], Cc[orden]) - val(F[x], Cc[orden]) || totFila[y] - totFila[x])
  else if (tras && !ordenNatural) idx.sort((x, y) => totFila[y] - totFila[x])
  const tenue = (i, j) => hov && hov[0] !== i && hov[1] !== j
  return (
    <div className="cu-matriz-env" ref={ref} onMouseLeave={() => setHov(null)}>
      <table className={`cu-calor${tras ? ' tras' : ''}${hov ? ' foco' : ''}`}>
        <caption className="sr-only">
          {ejeF} por {ejeC}. {modo === 'pct' ? 'Porcentaje de la cartera de cada institución.' : 'Cantidad de instrumentos.'} Pulse un encabezado de
          columna para ordenar las filas.
        </caption>
        <thead>
          <tr>
            <th scope="col" className="cu-calor-eje">
              {ejeF} <span>por {ejeC.toLowerCase()}</span>
              <small className="cu-calor-ayuda">{orden === null ? 'Pulse una columna para ordenar' : <button onClick={() => setOrden(null)}>Quitar orden</button>}</small>
            </th>
            {Cc.map((c, j) => (
              <th key={c.k} scope="col" title={c.title} className={`${hov && hov[1] === j ? 'hov' : ''}${orden === j ? ' ord' : ''}`} aria-sort={orden === j ? 'descending' : 'none'}>
                <button className="cu-calor-col" onClick={() => setOrden(orden === j ? null : j)}>
                  <span>{c.label}</span>
                  {c.sub && <small>{c.sub}</small>}
                </button>
              </th>
            ))}
            <th scope="col" className="cu-calor-tot">Total</th>
          </tr>
        </thead>
        <tbody>
          {idx.map((i, r) => {
            const f = F[i]
            return (
              <motion.tr key={f.k} layout={!reducir} transition={{ type: 'spring', stiffness: 320, damping: 32 }} className={hov && hov[0] === i ? 'hov' : ''}>
                <th scope="row" title={f.title}>
                  <span>{f.label}</span>
                  {f.sub && <small>{f.sub}</small>}
                </th>
                {Cc.map((c, j) => {
                  const lista = ins(f, c)
                  const v = val(f, c)
                  const [ok, ck] = orig(f, c)
                  const on = sel && sel[0] === ok && sel[1] === ck
                  const nv = nivel(v)
                  return (
                    <td key={c.k} className={`${hov && hov[1] === j ? 'hov' : ''}${tenue(i, j) ? ' tenue' : ''}`}>
                      <motion.button
                        className={`cu-calor-celda${lista.length ? '' : ' vacia'}${on ? ' on' : ''}${nv >= 3 ? ' osc' : ''}`}
                        style={nv >= 0 ? { background: RAMPA[nv] } : undefined}
                        initial={reducir ? false : { opacity: 0, scale: 0.4 }}
                        animate={visto || reducir ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.4 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 22, delay: visto ? (r + j) * 0.028 : 0 }}
                        whileHover={lista.length ? { scale: 1.12, zIndex: 2 } : undefined}
                        whileTap={lista.length ? { scale: 0.96 } : undefined}
                        disabled={!lista.length}
                        onMouseEnter={() => setHov([i, j])}
                        onFocus={() => setHov([i, j])}
                        onClick={() => onPick(on ? null : [ok, ck])}
                        aria-label={`${f.label}, ${c.label}: ${lista.length ? `${plural(lista.length, 'instrumento', 'instrumentos')}${modo === 'pct' ? ` (${v} %)` : ''}` : 'sin instrumentos registrados'}`}
                      >
                        {lista.length ? (modo === 'pct' ? `${v}%` : v) : ''}
                      </motion.button>
                    </td>
                  )
                })}
                <td className={`cu-calor-tot${hov && hov[0] !== i ? ' tenue' : ''}`}>
                  <motion.span
                    className="cu-calor-barra"
                    initial={reducir ? false : { scaleX: 0 }}
                    animate={{ scaleX: visto || reducir ? totFila[i] / maxTot : 0 }}
                    transition={{ duration: 0.9, ease, delay: visto ? 0.3 + r * 0.05 : 0 }}
                  />
                  <b>{visto ? <Counter value={totFila[i]} duration={0.9} /> : 0}</b>
                </td>
              </motion.tr>
            )
          })}
        </tbody>
        <tfoot>
          <tr>
            <th scope="row">Total</th>
            {Cc.map((c, j) => (
              <td key={c.k} className={hov && hov[1] === j ? 'hov' : ''}>{visto ? <Counter value={totCol[j]} duration={0.9} /> : 0}</td>
            ))}
            <td />
          </tr>
        </tfoot>
      </table>
    </div>
  )
}

export function LeyendaPuntos({ modo }) {
  return (
    <p className="cu-leyenda">
      <span className="cu-leyenda-rampa" aria-hidden="true">
        {RAMPA.slice(1).map((c) => <i key={c} style={{ background: c }} />)}
      </span>
      {modo === 'pct' ? 'Más oscuro, mayor peso en la cartera de la institución.' : 'Más oscuro, más instrumentos; el número es la cantidad.'}
      <span className="cu-leyenda-vacia" aria-hidden="true" />
      Celda vacía: sin instrumentos registrados en el relevamiento (no implica ausencia de apoyos fuera del portafolio). Los totales
      cuentan cada instrumento una vez.
    </p>
  )
}

/* ---------------------------------------------------------------- lista de instrumentos */
export function ListaInstrumentos({ titulo, detalle, ins, onOpen, onCerrar }) {
  return (
    <AnimatePresence mode="wait">
      {ins && (
        <motion.div key={titulo} className="cu-lista" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} transition={{ duration: 0.3, ease }}>
          <div className="cu-lista-cab">
            <div>
              <b>{titulo}</b>
              <span>
                {ins[0] && 'linea' in ins[0] ? plural(ins.length, 'línea de apoyo', 'líneas de apoyo') : plural(ins.length, 'instrumento', 'instrumentos')}
                {detalle ? ` · ${detalle}` : ''}
              </span>
            </div>
            <button className="cu-cerrar" onClick={onCerrar} aria-label="Cerrar lista">
              <Icon name="x" size={16} />
            </button>
          </div>
          <ul>
            {ins.map((i) => (
              <li key={i.id}>
                <button onClick={() => onOpen('linea' in i ? i.inst : i.id)}>
                  <span className="cu-sigla">{INST_MAP[i.institucion].sigla}</span>
                  {'linea' in i ? (
                    <span className="cu-lista-linea">
                      {i.instrumento}
                      <small>{i.linea}</small>
                    </span>
                  ) : (
                    i.nombre
                  )}
                </button>
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
