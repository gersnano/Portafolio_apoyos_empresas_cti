// Portada: pregunta y descripción, animación conceptual a todo el ancho y contadores debajo.
import { motion } from 'framer-motion'
import { Counter, ease } from './motion'
import Ecosistema from './Ecosistema'
import { FECHA_REFERENCIA, TOTALES } from '../lib/data'

const item = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease } } }

export default function Hero({ onOpen }) {
  return (
    <section className="pf-portada pf-portada-v2" id="inicio">
      <div className="pf-contenedor">
        <motion.div className="pf-portada-cab" initial="hidden" animate="show" transition={{ staggerChildren: 0.09 }}>
          <div>
            <motion.p variants={item} className="pf-antetitulo">
              <span aria-hidden="true" />Fecha de referencia: {FECHA_REFERENCIA}
            </motion.p>
            <motion.h1 variants={item} className="pf-portada-nombre">Portafolio de apoyo empresarial en CTI</motion.h1>
          </div>
          <motion.p variants={item} className="pf-descripcion">
            Una herramienta de información de la UNE-CTI que reúne y caracteriza los instrumentos públicos de apoyo empresarial en
            Uruguay. Permite explorar cuáles son los públicos objetivos, mecanismos y áreas de intervención, y ofrece una mirada integrada sobre la
            cobertura y complementariedad de la oferta pública de apoyos a las empresas.
          </motion.p>
        </motion.div>
      </div>

      <Ecosistema onOpen={onOpen} />

      <div className="pf-contenedor">

        <motion.div className="pf-contadores" initial="hidden" animate="show" transition={{ staggerChildren: 0.1, delayChildren: 0.4 }}>
          {[
            [TOTALES.instrumentos, 'Instrumentos', 'intervenciones públicas con identidad propia'],
            [TOTALES.lineas, 'Líneas de apoyo', 'modalidades operativas de los instrumentos'],
            [TOTALES.instituciones, 'Instituciones', 'agencias, ministerios e institutos'],
          ].map(([n, t, d]) => (
            <motion.div key={t} variants={item} className="pf-contador">
              <b><Counter value={n} /></b>
              <span>{t}</span>
              <small>{d}</small>
            </motion.div>
          ))}
          <motion.div variants={item} className="pf-acciones">
            <a className="pf-boton" href="#comprender">Comprender el sistema</a>
            <a className="pf-boton secundario" href="#explorar">Consultar la oferta</a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
