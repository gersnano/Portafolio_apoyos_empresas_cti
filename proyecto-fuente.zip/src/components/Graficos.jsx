// Visualizaciones de autor: flor radial del sistema (portada) y enjambre de etapas (d3-force).
import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { forceCollide, forceSimulation, forceX, forceY } from 'd3-force'
import { scaleSqrt } from 'd3-scale'
import { ease } from './motion'
import { INST_MAP, INSTITUCIONES, INSTRUMENTOS, STAGES5 } from '../lib/data'
import { familiaIns } from '../lib/sistema'

/* ---------------------------------------------------------------- flor del sistema */
/** Cada instrumento es un rayo: agrupados por institución, el largo crece con sus líneas y la cabeza indica la familia de mecanismo. */
export function FlorSistema({ onOpen, size = 640 }) {
  const [hover, setHover] = useState(null)
  const R0 = 70
  const items = useMemo(() => {
    const grupos = INSTITUCIONES.map((i) => INSTRUMENTOS.filter((x) => x.institucion === i.id).sort((a, b) => b.lineas.length - a.lineas.length))
    const gap = 0.12
    const total = INSTRUMENTOS.length
    const paso = (2 * Math.PI - gap * grupos.length) / total
    let ang = -Math.PI / 2
    const out = []
    const etiquetas = []
    grupos.forEach((g, gi) => {
      const ini = ang
      g.forEach((ins) => {
        out.push({ ins, ang, fam: familiaIns(ins) })
        ang += paso
      })
      etiquetas.push({ inst: INSTITUCIONES[gi], ang: (ini + ang - paso) / 2, max: Math.max(...g.map((x) => x.lineas.length)) })
      ang += gap
    })
    return { out, etiquetas }
  }, [])
  const largo = (n) => 70 + Math.min(n, 5) * 24
  const c = size / 2
  const h = hover && INSTRUMENTOS.find((i) => i.id === hover)
  return (
    <figure className="cu-flor">
      <svg viewBox={`0 0 ${size} ${size}`} role="img" aria-label={`Flor del sistema: ${INSTRUMENTOS.length} instrumentos agrupados por institución`}>
        <circle cx={c} cy={c} r={R0 - 12} fill="none" stroke="#c5d0db" strokeDasharray="2 4" />
        {items.out.map(({ ins, ang, fam }, k) => {
          const L = largo(ins.lineas.length)
          const x1 = c + Math.cos(ang) * R0
          const y1 = c + Math.sin(ang) * R0
          const x2 = c + Math.cos(ang) * (R0 + L)
          const y2 = c + Math.sin(ang) * (R0 + L)
          const on = !hover || hover === ins.id
          return (
            <g key={ins.id} style={{ cursor: 'pointer' }} onMouseEnter={() => setHover(ins.id)} onMouseLeave={() => setHover(null)} onClick={() => onOpen(ins.id)}>
              <motion.line
                x1={x1}
                y1={y1}
                stroke="#25408d"
                strokeWidth="0.9"
                initial={{ x2: x1, y2: y1, opacity: 0 }}
                animate={{ x2, y2, opacity: on ? 0.55 : 0.12 }}
                transition={{ duration: 1.1, ease, delay: 0.2 + k * 0.012 }}
              />
              <motion.circle
                r={3 + ins.lineas.length * 0.9}
                fill={fam.c}
                stroke="#fff"
                strokeWidth="0.8"
                initial={{ cx: x1, cy: y1, opacity: 0 }}
                animate={{ cx: x2, cy: y2, opacity: on ? 1 : 0.2 }}
                transition={{ duration: 1.1, ease, delay: 0.2 + k * 0.012 }}
              >
                <title>{`${ins.nombre} (${INST_MAP[ins.institucion].sigla}) · ${ins.lineas.length} líneas`}</title>
              </motion.circle>
            </g>
          )
        })}
        {items.etiquetas.map(({ inst, ang, max }) => {
          const rr = R0 + largo(max) + 26
          const izq = Math.cos(ang) < -0.2
          const der = Math.cos(ang) > 0.2
          return (
            <text key={inst.id} x={c + Math.cos(ang) * rr} y={c + Math.sin(ang) * rr} textAnchor={izq ? 'end' : der ? 'start' : 'middle'} dominantBaseline="middle" className="cu-flor-et">
              {inst.sigla}
            </text>
          )
        })}
        <text x={c} y={c - 6} textAnchor="middle" className="cu-flor-n">{h ? h.lineas.length : INSTRUMENTOS.length}</text>
        <text x={c} y={c + 14} textAnchor="middle" className="cu-flor-sub">{h ? (h.lineas.length === 1 ? 'línea' : 'líneas') : 'instrumentos'}</text>
      </svg>
      <figcaption>
        {h ? (
          <>
            <b>{h.nombre}</b> · {INST_MAP[h.institucion].nombre}
          </>
        ) : (
          'Cada rayo es un instrumento, agrupado por institución. El largo crece con sus líneas de apoyo y el color de la cabeza indica la familia de mecanismo.'
        )}
      </figcaption>
    </figure>
  )
}

/* ---------------------------------------------------------------- enjambre de etapas */
const COLS = [...STAGES5.map((e) => e.id), 'transversal']
/** Enjambre: un punto por instrumento en su etapa principal; los arcos unen con otras etapas que cubren sus líneas. */
export function EnjambreEtapas({ onOpen, foco, U, ancho = 1000, alto = 470 }) {
  const [hover, setHover] = useState(null)
  // unidad: instrumentos (por defecto) o líneas de apoyo
  const items = U ? U.items : INSTRUMENTOS
  const fam = U ? U.fam : familiaIns
  const etapaDe = U ? U.etapaPrincipal : (i) => i.etapa
  const otras = (x) => (U ? COLS.filter((e) => e !== 'transversal' && e !== etapaDe(x) && U.cubre(x, e)) : x.cobertura.filter((e) => e !== x.etapa))
  const tam = U ? U.tam : (i) => i.lineas.length
  const esLinea = U?.id === 'lin'
  const xs = useMemo(() => Object.fromEntries(COLS.map((e, k) => [e, 80 + (k * (ancho - 160)) / (COLS.length - 1)])), [ancho])
  const r = esLinea ? scaleSqrt().domain([1, 4]).range([4.5, 8]) : scaleSqrt().domain([1, 6]).range([7, 14])
  const base = alto - 150
  const nodos = useMemo(() => {
    const ns = items.map((ins) => ({ ins, fam: fam(ins), et: etapaDe(ins), x: xs[etapaDe(ins)], y: base, rad: r(Math.max(1, Math.min(tam(ins), esLinea ? 4 : 6))) }))
    const sim = forceSimulation(ns)
      .force('x', forceX((d) => xs[d.et]).strength(0.35))
      .force('y', forceY(base).strength(0.08))
      .force('c', forceCollide((d) => d.rad + 1.4))
      .stop()
    for (let i = 0; i < 260; i++) sim.tick()
    return ns
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [xs, base, items])
  const pos = Object.fromEntries(nodos.map((n) => [n.ins.id, n]))
  const arcos = items.flatMap((ins) => otras(ins).map((e) => ({ ins, desde: pos[ins.id], hasta: xs[e] })))
  const h = hover && pos[hover]
  return (
    <figure className="cu-enjambre">
      <svg viewBox={`0 0 ${ancho} ${alto}`} role="img" aria-label="Instrumentos por etapa principal, con arcos hacia otras etapas que cubren sus líneas">
        {COLS.map((e) => (
          <line key={e} x1={xs[e]} x2={xs[e]} y1={40} y2={alto - 40} stroke="#e1e7ee" strokeDasharray={e === 'transversal' ? '3 4' : undefined} />
        ))}
        {arcos.map(({ ins, desde, hasta }, k) => {
          const on = hover ? hover === ins.id : !foco || foco === fam(ins).id
          const xm = (desde.x + hasta) / 2
          const alt = Math.min(200, Math.abs(hasta - desde.x) * 0.55)
          return (
            <motion.path
              key={ins.id + hasta}
              d={`M${desde.x} ${desde.y} Q ${xm} ${desde.y - alt - 40} ${hasta} ${base - 40}`}
              fill="none"
              stroke={fam(ins).c}
              strokeWidth={hover === ins.id ? 2 : 1}
              initial={{ pathLength: 0, opacity: 0 }}
              whileInView={{ pathLength: 1, opacity: on ? (hover ? 0.9 : 0.45) : 0.06 }}
              animate={{ opacity: on ? (hover ? 0.9 : 0.45) : 0.06 }}
              viewport={{ once: true }}
              transition={{ pathLength: { duration: 1.2, ease, delay: 0.4 + k * 0.02 }, opacity: { duration: 0.3 } }}
            />
          )
        })}
        {nodos.map((n, k) => {
          const on = hover ? hover === n.ins.id : !foco || foco === n.fam.id
          return (
            <motion.circle
              key={n.ins.id}
              cx={n.x}
              r={n.rad}
              fill={n.fam.c}
              stroke="#fff"
              strokeWidth="1.2"
              initial={{ cy: 20, opacity: 0 }}
              whileInView={{ cy: n.y, opacity: on ? 1 : 0.15 }}
              animate={{ opacity: on ? 1 : 0.15 }}
              viewport={{ once: true }}
              transition={{ cy: { duration: 0.9, ease, delay: k * 0.008 }, opacity: { duration: 0.3 } }}
              style={{ cursor: 'pointer' }}
              onMouseEnter={() => setHover(n.ins.id)}
              onMouseLeave={() => setHover(null)}
              onClick={() => onOpen(esLinea ? n.ins.inst : n.ins.id)}
            >
              <title>{esLinea ? `${n.ins.instrumento}: ${n.ins.linea} (${INST_MAP[n.ins.institucion].sigla})` : `${n.ins.nombre} (${INST_MAP[n.ins.institucion].sigla})`}</title>
            </motion.circle>
          )
        })}
        {COLS.map((e, k) => {
          const st = STAGES5.find((s) => s.id === e)
          const n = items.filter((i) => etapaDe(i) === e).length
          return (
            <g key={e}>
              <text x={xs[e]} y={alto - 18} textAnchor="middle" className="cu-enj-et">{st ? `${st.orden}. ${st.corto}` : 'Transversal'}</text>
              <text x={xs[e]} y={alto - 2} textAnchor="middle" className="cu-enj-n">{n} {esLinea ? 'líneas' : 'instrumentos'}</text>
            </g>
          )
        })}
        {h && (
          <g pointerEvents="none">
            <rect x={Math.min(h.x + 12, ancho - 300)} y={Math.max(h.y - 58, 4)} width="290" height="44" rx="8" fill="#fff" stroke="#c5d0db" />
            <text x={Math.min(h.x + 24, ancho - 288)} y={Math.max(h.y - 38, 24)} className="cu-enj-tip-t">{(() => { const t = esLinea ? h.ins.instrumento : h.ins.nombre; return t.length > 40 ? t.slice(0, 39) + '…' : t })()}</text>
            <text x={Math.min(h.x + 24, ancho - 288)} y={Math.max(h.y - 21, 41)} className="cu-enj-tip-s">
              {INST_MAP[h.ins.institucion].sigla} · {esLinea ? (h.ins.linea.length > 34 ? h.ins.linea.slice(0, 33) + '…' : h.ins.linea) : `${h.ins.lineas.length} ${h.ins.lineas.length === 1 ? 'línea' : 'líneas'}`} · {h.fam.n.toLowerCase()}
            </text>
          </g>
        )}
      </svg>
    </figure>
  )
}
