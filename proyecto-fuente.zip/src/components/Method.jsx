import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Icon from './Icon'
import { Reveal, ease } from './motion'
import { CONTACTO, ETAPAS, FECHA_REFERENCIA, INSTITUCIONES, LINEAS, OPCIONES, TOTALES } from '../lib/data'
import { DIMENSION } from '../lib/sistema'

const FINALIDADES = [...new Set(LINEAS.map((l) => l.finalidad))].sort((a, b) => a.localeCompare(b, 'es'))
const MECANISMOS = OPCIONES.mecanismos.map(([m]) => m)
const ETAPAS_TAX = ETAPAS.map((e) => (e.orden < 6 ? `${e.orden}. ${e.nombre}` : e.nombre))

function Acordeon({ items }) {
  const [open, setOpen] = useState(-1)
  return (
    <div className="acc">
      {items.map((c, i) => (
        <div className="acc-item" key={c.titulo}>
          <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>
            {c.titulo}
            <motion.span animate={{ rotate: open === i ? 45 : 0 }} style={{ display: 'inline-flex', color: 'var(--muted)' }}>
              <Icon name="x" size={16} style={{ transform: 'rotate(45deg)' }} />
            </motion.span>
          </button>
          <AnimatePresence initial={false}>
            {open === i && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease }}
                style={{ overflow: 'hidden' }}
              >
                <div className="acc-body">{c.cuerpo}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  )
}

function Reporte() {
  const [agencia, setAgencia] = useState(INSTITUCIONES[0].id)
  const [instrumento, setInstrumento] = useState('')
  const [texto, setTexto] = useState('')
  const [reporte, setReporte] = useState('')
  const [estado, setEstado] = useState('')
  const preparar = (e) => {
    e.preventDefault()
    setReporte(
      `Reporte de corrección del Portafolio de apoyo empresarial en CTI\nAgencia: ${agencia}\nInstrumento o línea: ${instrumento}\n\nCorrección y evidencia:\n${texto}\n\nBase: Portafolio de apoyo empresarial en CTI (${TOTALES.instrumentos} instrumentos, ${TOTALES.lineas} líneas de apoyo)`,
    )
    setEstado('Reporte preparado. No se ha enviado.')
  }
  const copiar = async (valor, ok) => {
    try {
      await navigator.clipboard.writeText(valor)
      setEstado(ok)
    } catch {
      setEstado('Seleccione y copie el texto manualmente.')
    }
  }
  return (
    <div className="reporte">
      <p className="hint">
        {CONTACTO ? (
          <>
            Correcciones dirigidas a <b className="sel">{CONTACTO}</b>.{' '}
            <button className="linkbtn" onClick={() => copiar(CONTACTO, 'Dirección copiada.')}>
              Copiar dirección
            </button>
            <br />
            El formulario prepara el mensaje; el envío se realiza desde el correo de quien reporta.
          </>
        ) : (
          'Canal de envío: sin dato. El formulario permite preparar y copiar el reporte.'
        )}
      </p>
      <form onSubmit={preparar} className="reporte-form">
        <label>
          Agencia
          <select id="rep-agencia" value={agencia} onChange={(e) => setAgencia(e.target.value)} required>
            {INSTITUCIONES.map((a) => (
              <option key={a.id} value={a.id}>
                {a.sigla}
              </option>
            ))}
          </select>
        </label>
        <label>
          Instrumento o línea
          <input id="rep-instrumento" value={instrumento} onChange={(e) => setInstrumento(e.target.value)} required />
        </label>
        <label>
          Corrección y evidencia
          <textarea id="rep-texto" rows={4} value={texto} onChange={(e) => setTexto(e.target.value)} required />
        </label>
        <button className="btn btn-primary" type="submit">
          Preparar reporte
        </button>
      </form>
      <AnimatePresence>
        {reporte && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="reporte-form">
            <label>
              Reporte preparado
              <textarea id="rep-preparado" rows={8} readOnly value={reporte} />
            </label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn" onClick={() => copiar(reporte, 'Reporte copiado. No se ha enviado.')}>
                Copiar reporte
              </button>
              {CONTACTO && (
                <a
                  className="btn"
                  href={`mailto:${CONTACTO}?subject=${encodeURIComponent('Corrección del Portafolio de apoyo empresarial en CTI')}&body=${encodeURIComponent(reporte)}`}
                >
                  Enviar por correo
                </a>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <p className="hint" role="status">
        {estado}
      </p>
    </div>
  )
}

const CRITERIOS_GENERALES = [
  {
    titulo: 'Referencias expertas',
    cuerpo:
      'Los instrumentos con una referencia experta directa toman la etapa que esta indica. Los demás se asignan por analogía con la referencia experta más cercana en tipo de apoyo. Cada línea toma la etapa de su instrumento, salvo que otra referencia experta sostenga una etapa distinta.',
  },
  {
    titulo: 'Cobertura de varias etapas',
    cuerpo:
      'Que un instrumento cubra una etapa indica el tipo de apoyo que ofrece; no constituye prueba de elegibilidad ni derecho al beneficio.',
  },
  {
    titulo: 'Eje transversal',
    cuerpo:
      'Los apoyos transversales se registran como un atributo separado de las etapas. No se presume que sean elegibles en todas las etapas.',
  },
  {
    titulo: 'Revisión con bases y fichas oficiales',
    cuerpo:
      'Cada línea se contrastó con sus bases y fichas oficiales. Un ajuste de clasificación se acepta solo cuando la fuente lo establece de forma explícita (rubro financiable, área priorizada o condición del apoyo) y se descarta cuando la mención corresponde a otra línea, a un requisito, a un resultado esperado o a un documento común a varias modalidades.',
  },
  {
    titulo: 'Palabras clave y similitud',
    cuerpo:
      'Cada instrumento tiene palabras clave calculadas con TF-IDF: términos frecuentes en el instrumento y poco frecuentes en el resto del portafolio. Se extraen de sus bases y fichas oficiales cuando pueden leerse y, en su defecto, de la descripción registrada en el portafolio. La similitud entre instrumentos combina esa cercanía de vocabulario con la coincidencia de apoyos, capacidades, mecanismos y etapas.',
  },
  {
    titulo: 'Alcance del universo',
    cuerpo:
      'El universo comprende los instrumentos cuyas líneas tienen a empresas o unidades productivas entre sus destinatarios, incluidas las de público mixto. Quedan fuera los instrumentos cuyo destinatario directo son personas o instituciones que no son empresas.',
  },
]

const ALTO_PLEGADO = 460 // alto visible de la vista previa (px)

export default function Method() {
  const nAgencias = INSTITUCIONES.length
  const [abierta, setAbierta] = useState(false)
  const alternar = () => {
    if (abierta) document.getElementById('metodologia')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setAbierta((a) => !a)
  }
  return (
    <section className="section alt cu-notas" id="metodologia">
      <div className="wrap">
        <div className="section-head">
          <Reveal>
            <p className="pf-antetitulo"><span aria-hidden="true" />Notas metodológicas</p>
            <h2>Metodología y fuentes</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p>Universo, criterios de clasificación, definiciones y fuentes del relevamiento.</p>
          </Reveal>
        </div>

        <motion.div
          id="metodologia-cuerpo"
          className={`cu-plegable${abierta ? ' abierta' : ''}`}
          initial={false}
          animate={{ height: abierta ? 'auto' : ALTO_PLEGADO }}
          transition={{ duration: 0.6, ease }}
        >
        <div className="method">
          <Reveal as="article" className="card metodo">
            <p className="relevamiento">
              Fecha de referencia del relevamiento: <b>{FECHA_REFERENCIA}</b> · {TOTALES.instrumentos} instrumentos ·{' '}
              {TOTALES.lineas} líneas de apoyo · {nAgencias} instituciones
            </p>

            <h3>Instrumentos y líneas de apoyo</h3>
            <p>
              Un instrumento es una intervención pública con identidad propia, identificada en la base mediante un código.
              Una línea de apoyo es una modalidad operativa de ese instrumento, con su propio público, prestación y
              condiciones. Un instrumento puede tener varias líneas, por lo que la suma de líneas no equivale al número de
              instrumentos. Los programas interinstitucionales se cuentan bajo la institución que registra la base. La
              inclusión en el catálogo no acredita una convocatoria abierta.
            </p>

            <h3>Universo y criterios de clasificación</h3>
            <p>
              El relevamiento comprende {TOTALES.instrumentos} instrumentos y {TOTALES.lineas} líneas de apoyo. La
              clasificación considera tres dimensiones: necesidades empresariales, mecanismos de apoyo y etapas de desarrollo.
            </p>
            <p>
              Los instrumentos se contabilizan según su etapa principal. Una línea puede asociarse a más de una etapa
              únicamente cuando existe respaldo de una referencia experta.
            </p>
            <p>
              Esta clasificación tiene fines analíticos y no implica que los instrumentos tengan convocatorias abiertas ni que
              todas las empresas puedan acceder a ellos.
            </p>

            <h3>Necesidades empresariales</h3>
            <p>
              Las necesidades se clasifican según las finalidades operativas de cada línea de apoyo. Las fichas de los
              instrumentos conservan, además, la finalidad estratégica que orienta su intervención.
            </p>
            <p>
              Un mismo instrumento puede contar con varias líneas dirigidas a distintas necesidades. Por este motivo, puede
              aparecer asociado a más de una categoría y los conteos por necesidad no son acumulables entre sí.
            </p>

            <h3>Mecanismos y tipos de apoyo</h3>
            <p>
              Se mantiene la taxonomía de mecanismos utilizada en la base de datos: subsidios, crédito, capital, garantías,
              incentivos fiscales, servicios, acceso a activos, demanda o regulación, premios e información.
            </p>
            <p>
              La asistencia técnica, la capacitación y los servicios tecnológicos se describen como prestaciones en las fichas
              de cada instrumento. No se consideran mecanismos excluyentes, dado que pueden combinarse con otros mecanismos
              dentro de una misma línea de apoyo y no existe una regla de clasificación validada que justifique tratarlos como
              categorías independientes.
            </p>

            <h3>Etapas y trayectoria empresarial</h3>
            <p>
              La clasificación funcional contempla cinco etapas: ideación y prueba; investigación y desarrollo; puesta en
              marcha; consolidación y crecimiento; e internacionalización y escalamiento. El eje transversal se presenta por
              separado.
            </p>
            <p>
              Estas etapas describen el tipo de actividad, necesidad o proyecto al que se orienta el apoyo, y no
              necesariamente la antigüedad, el tamaño o el grado de madurez de la empresa. Tampoco representan una secuencia
              obligatoria que todas las empresas deban recorrer ni determinan por sí mismas los requisitos de elegibilidad de
              los instrumentos.
            </p>

            <h3>Definiciones de las dimensiones</h3>
            <dl className="definiciones">
              {[
                ['Necesidad empresarial', DIMENSION.finalidad.def],
                ['Mecanismo', 'Cómo se instrumenta el apoyo (subsidio, crédito, garantía o asistencia técnica).'],
                ['Tipo de apoyo', 'Qué prestación concreta ofrece (financiamiento, capacitación, asesoramiento, acceso a infraestructura, etc.).'],
                ['Capacidad', 'Qué capacidades busca desarrollar o fortalecer (tecnológicas, de gestión, productivas, comerciales, de innovación, etc.).'],
                ['Acceso', 'Cuáles son las condiciones y modalidades para acceder (convocatoria, ventanilla abierta, postulación directa, etc.).'],
                ['Etapa de desarrollo', DIMENSION.etapa.def],
              ].map(([n, d]) => (
                <div key={n}>
                  <dt>{n}</dt>
                  <dd>{d}</dd>
                </div>
              ))}
            </dl>
            <p className="hint">
              Es importante distinguir entre mecanismo y tipo de apoyo: el primero refiere a cómo se canaliza el apoyo y el
              segundo a qué recibe concretamente la empresa.
            </p>

            <h3>Qué se cuenta</h3>
            <p>
              Salvo que se indique lo contrario, los gráficos cuentan instrumentos. Un instrumento pertenece a una categoría
              cuando al menos una de sus líneas la tiene; por eso, en necesidades, mecanismos, tipos de apoyo y etapas, las sumas
              pueden superar el total de instrumentos. Cada instrumento se cuenta una sola vez dentro de cada categoría, aunque
              varias de sus líneas la compartan.
            </p>
            <p>
              En el análisis por institución, la cantidad indica cuántos instrumentos tiene cada institución en una categoría y
              el porcentaje, qué parte de su cartera representan. Ninguna de las dos medidas expresa presupuesto, cobertura,
              efectividad ni impacto.
            </p>
            <h3>Datos faltantes y ausencia de apoyos</h3>
            <p>
              Cuando un campo no está disponible se indica «sin dato en el relevamiento». Una celda vacía en una matriz significa
              que no hay instrumentos registrados con esa combinación en el portafolio relevado; no demuestra que no existan
              apoyos en el país ni constituye, por sí sola, un vacío de política.
            </p>

            <h4 className="mini-head">Taxonomías de la base</h4>
            <div className="tax">
              {[
                ['Necesidades empresariales', FINALIDADES],
                ['Mecanismos', MECANISMOS],
                ['Etapas', ETAPAS_TAX],
              ].map(([nombre, valores]) => (
                <div key={nombre}>
                  <b>{nombre}</b>
                  <ul>
                    {valores.map((v) => (
                      <li key={v}>{v}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h3>Criterios y límites de interpretación</h3>
            <p>
              La coincidencia de necesidad no prueba duplicación. El mapa muestra presencia de oferta registrada; para analizar
              complementariedades se requiere contrastar público, prestaciones y condiciones.
            </p>
            <p>
              El estado activo refleja la validación del relevamiento a la fecha de referencia. No indica apertura permanente de
              convocatorias. Montos, porcentajes de cofinanciamiento, períodos de apertura y fechas individuales de relevamiento
              no están disponibles como campos estructurados y se muestran como sin dato. No se derivan de descripciones
              generales. Las fuentes deben consultarse para determinar condiciones vigentes.
            </p>
            <p>
              La actualización del sitio no sustituye una fecha de relevamiento o verificación de cada convocatoria.
            </p>
            <p>
              El catálogo no mide beneficiarios, recursos ejecutados, demanda insatisfecha, adicionalidad ni impacto. La ausencia
              en una celda describe el registro disponible, no necesariamente la ausencia de capacidades en Uruguay. La confianza
              documental de cada línea se conserva en su ficha. La actualización de la base no es automática.
            </p>

            <h3>Criterios de clasificación y revisión</h3>
            <Acordeon items={CRITERIOS_GENERALES} />
          </Reveal>

          <Reveal as="aside" className="card" delay={0.1}>
            <h3 className="aside-h">Fuentes</h3>
            <p className="fuentes-texto">
              La información proviene de las fichas, bases y documentos oficiales publicados por cada institución, sistematizados
              por la UNE-CTI. Cada ficha de instrumento remite a sus fuentes oficiales, que deben consultarse para conocer las
              condiciones vigentes.
            </p>
            <ul className="instituciones-fuente">
              {INSTITUCIONES.map((a) => (
                <li key={a.id}>
                  <b>{a.sigla}</b> {a.nombre}
                </li>
              ))}
            </ul>
            <h3 className="aside-h" style={{ marginTop: 28 }}>
              Reporte de correcciones
            </h3>
            <Reporte />
          </Reveal>
        </div>
          {!abierta && <div className="cu-plegable-velo" aria-hidden="true" />}
        </motion.div>
        <div className="cu-plegable-accion">
          <button type="button" className="cu-plegable-boton" aria-expanded={abierta} aria-controls="metodologia-cuerpo" onClick={alternar}>
            {abierta ? 'Mostrar menos' : 'Ver la metodología y las fuentes completas'}
            <motion.span aria-hidden="true" className="cu-plegable-chevron" animate={{ rotate: abierta ? 180 : 0 }} transition={{ duration: 0.3, ease }}>
              <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 5l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </motion.span>
          </button>
        </div>
      </div>
    </section>
  )
}
