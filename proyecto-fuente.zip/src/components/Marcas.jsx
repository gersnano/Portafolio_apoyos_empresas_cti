// Identidad de las instituciones: logos sin modificar (solo se recortan márgenes vacíos) con peso visual igualado,
// e íconos propios del portafolio.
import LOGOS from '../assets/logos/logos.json'
import ande from '../assets/logos/ande.png'
import anii from '../assets/logos/anii.png'
import inacoop from '../assets/logos/inacoop.png'
import inefop from '../assets/logos/inefop.png'
import inia from '../assets/logos/inia.png'
import latu from '../assets/logos/latu.png'
import uruguayxxi from '../assets/logos/uruguayxxi.png'
import { INST_MAP } from '../lib/data'

const SRC = { ANDE: ande, ANII: anii, INACOOP: inacoop, INEFOP: inefop, INIA: inia, LATU: latu, 'URUGUAY XXI': uruguayxxi }
const CLAVE = { 'URUGUAY XXI': 'Uruguay XXI' }

/** Logo de una institución. El tamaño iguala el área de tinta entre logos; `escala` lo ajusta al contexto.
 *  Si no se dispone del logo, se muestra la sigla en un rótulo neutro del mismo peso (sin imitar la marca). */
export function LogoInstitucion({ id, escala = 1, className = '' }) {
  const info = LOGOS[CLAVE[id] || id]
  const inst = INST_MAP[id]
  if (!info || !SRC[id]) {
    return (
      <span className={`pf-logo-texto ${className}`} style={{ fontSize: 22 * escala }} role="img" aria-label={inst?.nombre || id}>
        {inst?.sigla || id}
        <small style={{ fontSize: 9 * escala }}>{inst?.nombre}</small>
      </span>
    )
  }
  return (
    <img
      className={`pf-logo ${className}`}
      src={SRC[id]}
      alt={inst?.nombre || id}
      width={Math.round(info.ancho * escala)}
      height={Math.round(info.alto * escala)}
      style={{ width: info.ancho * escala, height: info.alto * escala }}
      loading="lazy"
    />
  )
}

/* ---------------------------------------------------------------- íconos (trazo 1.6, 24×24) */
const P = {
  quien: <><path d="M3 21h18M5 21V10m14 11V10M9 21v-6h6v6" /><path d="M3 10l9-6 9 6" /></>,
  que: <><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="0.8" fill="currentColor" /></>,
  como: <><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 0 5.4-5.4l-2.4 2.4-2.6-.6-.6-2.6z" /></>,
  cuando: <><path d="M3 12h18" /><circle cx="5" cy="12" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="19" cy="12" r="2" /><path d="M12 4v3M12 17v3" /></>,
  explorar: <><circle cx="11" cy="11" r="6" /><path d="M20 20l-4.3-4.3" /></>,
  instituciones: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
  notas: <><path d="M5 4h10l4 4v12H5z" /><path d="M14 4v5h5M8 13h8M8 17h6" /></>,
  tabla: <><rect x="3" y="5" width="18" height="14" rx="1.5" /><path d="M3 10h18M3 15h18M9 5v14" /></>,
  descargar: <><path d="M12 4v11M7 10l5 5 5-5M5 20h14" /></>,
  copiar: <><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" /></>,
  lectura: <><path d="M4 5h6a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H4zM20 5h-6a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h6z" /></>,
  cuenta: <><path d="M5 7h14M5 12h14M5 17h9" /></>,
  hallazgo: <><path d="M9 18h6M10 21h4" /><path d="M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z" /></>,
  // familias de mecanismo
  sub: <><circle cx="12" cy="12" r="8" /><path d="M14.5 9.2c-.5-.8-1.4-1.2-2.5-1.2-1.5 0-2.6.8-2.6 2s1.1 1.6 2.6 2 2.6.8 2.6 2-1.1 2-2.6 2c-1.1 0-2.1-.5-2.6-1.3M12 6.5V8m0 8v1.5" /></>,
  fin: <><path d="M3 10l9-5 9 5M5 10v8m4-8v8m6-8v8m4-8v8M3 20h18" /></>,
  ser: <><path d="M12 3l2.2 4.6 5 .7-3.6 3.5.8 5L12 14.5 7.6 16.8l.8-5L4.8 8.3l5-.7z" /></>,
  inc: <><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0z" /><path d="M7 6H4a3 3 0 0 0 3 3M17 6h3a3 3 0 0 1-3 3" /></>,
  inf: <><rect x="4" y="4" width="16" height="6" rx="1.5" /><rect x="4" y="14" width="16" height="6" rx="1.5" /><path d="M8 7h.01M8 17h.01" /></>,
}
export function Ico({ n, size = 20, className = '', title }) {
  return (
    <svg className={`pf-ico ${className}`} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden={title ? undefined : 'true'} role={title ? 'img' : undefined}>
      {title && <title>{title}</title>}
      {P[n]}
    </svg>
  )
}

/** Marca del producto: mosaico de puntos (cada punto, un instrumento) en las cinco familias. */
/** Marca del portafolio: un haz de filamentos que se estrecha en un nodo y una empresa (punto dorado) que lo atraviesa. */
export function MarcaPortafolio({ size = 34 }) {
  const hilos = [-9, -5.5, -2, 2, 5.5, 9]
  return (
    <svg width={size} height={size} viewBox="0 0 34 34" aria-hidden="true">
      <rect width="34" height="34" rx="9" fill="#0f2a5c" />
      {hilos.map((d, i) => (
        <path
          key={d}
          d={`M4 ${17 + d * 0.55} C 10 ${17 + d * 0.9}, 13 17, 17 17 S 25 ${17 - d * 1.05}, 30 ${17 + d * 0.95}`}
          fill="none"
          stroke={i % 2 ? '#93acd6' : '#c6d4ea'}
          strokeWidth="1"
          strokeLinecap="round"
          opacity={0.55 + (i % 3) * 0.15}
        />
      ))}
      <circle cx="17" cy="17" r="4.2" fill="none" stroke="#c7a044" strokeWidth="1" opacity="0.8" />
      <circle cx="23.5" cy="14.2" r="2.4" fill="#e0b13f" />
      <circle cx="23.5" cy="14.2" r="0.95" fill="#faf5dd" />
    </svg>
  )
}

/** Logotipo de la UNE (trazo) con el nombre completo, como en la versión anterior del sitio. */
export function LogoUNE({ conNombre = true }) {
  return (
    <span className="pf-une">
      <svg viewBox="0 0 674 200" height="26" width="87.6" role="img" aria-label="UNE">
        <path
          d="M23 23 V100 A77 77 0 0 0 177 100 V23 M268 177 V60 A37 37 0 0 1 342 60 V140 A37 37 0 0 0 416 140 V23 M651 23 H545.5 A38.5 38.5 0 0 0 545.5 100 H651 M545.5 100 A38.5 38.5 0 0 0 545.5 177 H651"
          fill="none"
          stroke="currentColor"
          strokeWidth="46"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      {conNombre && (
        <>
          <span className="pf-une-regla" aria-hidden="true" />
          <span className="pf-une-nombre">
            Unidad Nacional de Evaluación del Sistema
            <br />
            de Ciencia, Tecnología e Innovación
          </span>
        </>
      )}
    </span>
  )
}
