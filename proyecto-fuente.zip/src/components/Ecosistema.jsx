// Apertura · campo de filamentos del ecosistema.
// 114 filamentos (uno por línea de apoyo, agrupados y coloreados por institución) corren de izquierda a derecha.
// Cinco nodos —las etapas empresariales— cierran el campo; la empresa que llega se tranca, aparece un instrumento real
// de esa etapa, el nodo se abre y la empresa acelera hasta el siguiente nodo cerrado. Ocho empresas navegan a la vez. Canvas 2D + requestAnimationFrame; respeta prefers-reduced-motion.
import { useEffect, useMemo, useRef, useState } from 'react'
import { useReducedMotion } from 'framer-motion'
import { ETAPAS, INST_MAP, INSTITUCIONES, INSTRUMENTOS, LINEAS } from '../lib/data'
import { VALORES } from '../lib/sistema'

const H = 580 // alto lógico; el ancho lógico se adapta al ancho real (la animación ocupa toda la página)
const TAU = Math.PI * 2
const PALETA = ['#254769', '#3e6280', '#5d7d96', '#8998a8', '#a28b58', '#c7a044', '#a18c88', '#7b7894']
const VELOCIDAD = 0.8 // ritmo de las empresas respecto del original
const NODOS = [0.15, 0.32, 0.49, 0.66, 0.83]
const COLORES_EMPRESAS = ['#c79b34', '#dbac47', '#466d9a', '#526e81', '#a77843', '#d99062', '#6c66a2']

const clamp = (v) => Math.max(0, Math.min(1, v))
const ease = (v) => {
  const x = clamp(v)
  return x * x * (3 - 2 * x)
}
const gauss = (v, s) => Math.exp((-v * v) / (2 * s * s))

function dividirTexto(texto, max = 24) {
  const lineas = []
  let linea = ''
  for (const palabra of texto.split(' ')) {
    if (`${linea} ${palabra}`.trim().length > max) {
      if (linea) lineas.push(linea)
      linea = palabra
    } else linea = `${linea} ${palabra}`.trim()
  }
  if (linea) lineas.push(linea)
  return lineas.slice(0, 3)
}

export default function Ecosistema({ onOpen }) {
  const reducir = useReducedMotion()
  const lienzo = useRef(null)
  const estado = useRef({ pausa: false, rotulos: [], tPausa: 0, desfase: 0 })
  const [pausa, setPausa] = useState(false)
  const [mano, setMano] = useState(false)

  const modelo = useMemo(() => {
    // filamentos: uno por línea de apoyo, ordenados por institución (cada institución, un color)
    const instOrden = [...INSTITUCIONES].sort((a, b) => LINEAS.filter((l) => l.institucion === b.id).length - LINEAS.filter((l) => l.institucion === a.id).length)
    const grupoDe = Object.fromEntries(instOrden.map((i, k) => [i.id, k % PALETA.length]))
    const filamentos = [...LINEAS].sort((a, b) => grupoDe[a.institucion] - grupoDe[b.institucion]).map((l) => grupoDe[l.institucion])
    // instrumentos por etapa (los cinco nodos)
    const porEtapa = ETAPAS.slice(0, 5).map((et) => INSTRUMENTOS.filter((i) => VALORES.etapa(i).includes(et.id)))
    const empresas = Array.from({ length: 8 }, (_, i) => ({
      offset: i * 3.15,
      trayectoria: Math.sin(i * 5.3) * 0.73,
      color: COLORES_EMPRESAS[i % COLORES_EMPRESAS.length],
      velocidad: 1 + (i % 3) * 0.06,
    }))
    return { filamentos, porEtapa, empresas }
  }, [])

  useEffect(() => {
    estado.current.pausa = pausa
  }, [pausa])

  useEffect(() => {
    const cv = lienzo.current
    const ctx = cv.getContext('2d')
    const { filamentos, porEtapa, empresas } = modelo
    let W = 1000
    const apertura = [0, 0, 0, 0, 0] // 0 = nodo cerrado, 1 = abierto
    const etiqueta = [0, 0, 0, 0, 0]
    const elegido = porEtapa.map((l) => l[Math.floor(Math.random() * l.length)])
    const abierto = [false, false, false, false, false]
    let raf = 0

    // geometría del campo de filamentos
    const campo = (u, v, grupo, t) => {
      const centro = 284 + 33 * Math.sin(u * TAU * 1.12 - 0.75) + 24 * Math.sin(u * TAU * 2.2 + 0.7)
      let ancho = 25 + 142 * u ** 0.8
      NODOS.forEach((nodo, i) => {
        ancho *= 1 - (0.84 - apertura[i] * 0.7) * gauss(u - nodo, 0.035)
      })
      let y = centro + v * ancho * (0.62 + 0.38 * Math.cos(u * TAU * 2.7 + v * 2 + t * 0.1))
      y += 13 * Math.sin(u * TAU * 2.6 + v * 1.5 + t * 0.14) * Math.sin(Math.PI * u)
      y += Math.sin(v * 7 + grupo * 0.9 + u * TAU * 2.3) * 15 * Math.sin(Math.PI * u)
      const x = W * 0.01 + W * 0.98 * u + Math.sin(v * 4 + u * TAU * 2.2 + t * 0.11) * 14 * Math.sin(Math.PI * u)
      return [x, y]
    }

    // trayectoria de cada empresa: avanza hasta el próximo nodo cerrado y se TRANCA; aparece el programa; el nodo se
    // abre, la deja pasar y la empresa ACELERA hasta el siguiente nodo cerrado. Ciclo de 24 s: 5 nodos + salida.
    const inOut = (k) => (k < 0.5 ? 4 * k * k * k : 1 - (-2 * k + 2) ** 3 / 2)
    const recorrido = (t, emp) => {
      const tiempo = (((t * emp.velocidad + emp.offset) % 24) + 24) % 24
      const s2 = Math.floor(tiempo / 4)
      const local = tiempo % 4
      const desde = s2 ? NODOS[s2 - 1] + 0.012 : 0
      // el nodo que acaba de cruzar se vuelve a cerrar y su rótulo se apaga
      const r = { nodo: s2 < 5 ? s2 : -1, abre: 0, etiqueta: 0, tranca: 0, prev: s2 - 1, prevAbre: s2 ? 1 - ease(local / 0.7) : 0, prevEtiqueta: s2 ? 1 - ease(local / 0.6) : 0 }
      if (s2 >= 5) {
        r.u = desde + (1 - desde) * clamp(local / 3.4) ** 2.2
        return r
      }
      const hasta = NODOS[s2] - 0.014 // se detiene justo antes del estrechamiento
      if (local < 1.8) r.u = desde + (hasta - desde) * inOut(local / 1.8)
      else if (local < 3.2) {
        r.u = hasta
        r.tranca = ease((local - 1.8) / 0.3)
      } else {
        const k = ease((local - 3.2) / 0.8)
        r.u = hasta + (NODOS[s2] + 0.012 - hasta) * k * k
      }
      r.etiqueta = ease((local - 1.9) / 0.4)
      r.abre = local > 3 ? ease((local - 3) / 0.7) : 0
      return r
    }

    const punto = (p, radio, color, alfa = 1) => {
      ctx.fillStyle = color
      ctx.globalAlpha = alfa
      ctx.beginPath()
      ctx.arc(p[0], p[1], radio, 0, TAU)
      ctx.fill()
      ctx.globalAlpha = 1
    }
    const resplandor = (p, radio, color) => {
      const g = ctx.createRadialGradient(p[0], p[1], 0, p[0], p[1], radio)
      g.addColorStop(0, color)
      g.addColorStop(1, 'rgba(201,157,50,0)')
      ctx.fillStyle = g
      ctx.fillRect(p[0] - radio, p[1] - radio, radio * 2, radio * 2)
    }

    // rótulo del instrumento que responde en el nodo abierto
    const mostrarInstrumento = (i, p, alfa) => {
      const ins = elegido[i]
      if (!ins) return
      const arriba = i % 2 === 0
      const y = arriba ? 112 : 420
      const x = Math.max(115, Math.min(W - 115, p[0]))
      ctx.globalAlpha = alfa
      ctx.strokeStyle = '#b69c60'
      ctx.lineWidth = 0.7
      ctx.beginPath()
      ctx.moveTo(p[0], p[1])
      ctx.lineTo(x, arriba ? y + 15 : y - 19)
      ctx.stroke()
      ctx.textAlign = 'center'
      ctx.textBaseline = 'alphabetic'
      ctx.fillStyle = '#9b772e'
      ctx.font = '600 12px "DM Sans", system-ui, sans-serif'
      ctx.fillText(`${INST_MAP[ins.institucion].sigla}, ${ETAPAS[i].nombre.toLowerCase()}`, x, y - 8)
      ctx.fillStyle = '#274565'
      ctx.font = '15px Literata, Georgia, serif'
      dividirTexto(ins.nombre).forEach((linea, j) => ctx.fillText(linea, x, y + 12 + j * 18))
      ctx.globalAlpha = 1
      estado.current.rotulos.push({ x1: x - 105, x2: x + 105, y1: y - 24, y2: y + 50, id: ins.id, nombre: ins.nombre })
    }

    function render(ms) {
      const e = estado.current
      // la pausa congela el tiempo de la animación
      if (e.pausa) {
        if (!e.tPausa) e.tPausa = ms
      } else if (e.tPausa) {
        e.desfase += ms - e.tPausa
        e.tPausa = 0
      }
      const t = ((e.tPausa || ms) - e.desfase) / 1000
      ctx.clearRect(0, 0, W, H)
      e.rotulos = []
      apertura.fill(0)
      etiqueta.fill(0)
      const tr = t * VELOCIDAD // tiempo del recorrido de las empresas (más lento que el de los filamentos)
      const estados = empresas.map((emp) => recorrido(tr, emp))
      estados.forEach((es) => {
        if (es.nodo >= 0) {
          apertura[es.nodo] = Math.max(apertura[es.nodo], es.abre)
          etiqueta[es.nodo] = Math.max(etiqueta[es.nodo], es.etiqueta)
        }
        if (es.prev >= 0 && es.prev < NODOS.length) {
          apertura[es.prev] = Math.max(apertura[es.prev], es.prevAbre)
          etiqueta[es.prev] = Math.max(etiqueta[es.prev], es.prevEtiqueta)
        }
      })
      // cuando una empresa se tranca en un nodo, aparece un instrumento de esa etapa
      etiqueta.forEach((a, i) => {
        if (a > 0.02 && !abierto[i]) {
          const l = porEtapa[i]
          elegido[i] = l[Math.floor(Math.random() * l.length)]
          abierto[i] = true
        } else if (a <= 0.02) abierto[i] = false
      })

      // filamentos del ecosistema
      filamentos.forEach((grupo, i) => {
        const v = (i / (filamentos.length - 1)) * 2 - 1
        ctx.beginPath()
        for (let j = 0; j <= 150; j++) {
          const p = campo(j / 150, v, grupo, t)
          if (j === 0) ctx.moveTo(p[0], p[1])
          else ctx.lineTo(p[0], p[1])
        }
        ctx.strokeStyle = PALETA[grupo]
        ctx.lineWidth = 0.66
        ctx.globalAlpha = 0.255
        ctx.stroke()
      })
      ctx.globalAlpha = 1

      // activación de los nodos
      NODOS.forEach((nodo, i) => {
        const p = campo(nodo, 0, 3, t)
        const k = Math.max(apertura[i], etiqueta[i] * 0.6)
        if (k > 0) {
          resplandor(p, 48, `rgba(201,157,50,${k * 0.18})`)
          ctx.strokeStyle = '#c6a052'
          ctx.globalAlpha = k * 0.52
          ctx.lineWidth = 0.8
          ctx.beginPath()
          ctx.arc(p[0], p[1], 9 + k * 19, 0, TAU)
          ctx.stroke()
          ctx.globalAlpha = 1
        }
      })

      // empresas navegando a la vez
      empresas.forEach((emp, i) => {
        const es = estados[i]
        const p = campo(es.u, emp.trayectoria, i, t)
        if (es.tranca) {
          // atascada: tiembla contra el nodo cerrado
          p[0] += Math.sin(t * 38 + i) * 0.9 * es.tranca
          p[1] += Math.cos(t * 31 + i * 2) * 0.7 * es.tranca
        }
        for (let j = 20; j >= 1; j--) {
          const ant = recorrido(tr - j * 0.024 * VELOCIDAD, emp).u
          if (ant > es.u) continue
          punto(campo(ant, emp.trayectoria, i, t), 1.2 + (1 - j / 21) * 1.7, emp.color, (1 - j / 21) * 0.34)
        }
        resplandor(p, 14, 'rgba(201,157,50,0.22)')
        punto(p, 4.2, emp.color)
        punto(p, 1.6, '#faf5dd')
      })

      // instrumentos activados
      NODOS.forEach((nodo, i) => {
        if (etiqueta[i] > 0.05) mostrarInstrumento(i, campo(nodo, 0, 3, t), etiqueta[i])
      })

      if (!reducir) raf = requestAnimationFrame(render)
    }

    const ajustar = () => {
      const r = cv.getBoundingClientRect()
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      cv.width = Math.max(1, Math.round(r.width * dpr))
      cv.height = Math.max(1, Math.round(r.height * dpr))
      W = Math.max(600, (H * r.width) / Math.max(1, r.height))
      estado.current.W = W
      ctx.setTransform(cv.width / W, 0, 0, cv.height / H, 0, 0)
      if (reducir) render(3000)
    }
    const ro = new ResizeObserver(ajustar)
    ro.observe(cv)
    ajustar()
    if (!reducir) raf = requestAnimationFrame(render)
    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
    }
  }, [modelo, reducir])

  // clic en el rótulo de un instrumento: abre su ficha
  const enRotulo = (ev) => {
    const b = ev.currentTarget.getBoundingClientRect()
    const x = ((ev.clientX - b.left) / b.width) * (estado.current.W || 1000)
    const y = ((ev.clientY - b.top) / b.height) * H
    return estado.current.rotulos.find((r) => x >= r.x1 && x <= r.x2 && y >= r.y1 && y <= r.y2)
  }

  return (
    <figure className="pf-lateral" aria-roledescription="animación" aria-label="Empresas que recorren el ecosistema de apoyos: en cada etapa se abre un nodo y aparece un instrumento">
      <canvas
        ref={lienzo}
        className="pf-filamentos"
        aria-hidden="true"
        onMouseMove={(ev) => setMano(!!enRotulo(ev))}
        onMouseLeave={() => setMano(false)}
        onClick={(ev) => {
          const r = enRotulo(ev)
          if (r) onOpen?.(r.id)
        }}
        style={{ cursor: mano ? 'pointer' : 'default' }}
      />
      <div className="pc-pie">
        <button onClick={() => setPausa((p) => !p)} aria-pressed={pausa} className="pf-eco-pausa">{pausa ? '▶ Reanudar' : '❚❚ Pausar'}</button>
      </div>
    </figure>
  )
}
