// Parte 1 · Comprender el sistema: cuatro capítulos con gráficos y relato (qué muestra, cómo leerlo, qué se observa).
import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ease } from './motion'
import { Capitulo, Familias, Grafico, ListaInstrumentos, Lollipops, LeyendaPuntos, MatrizPuntos } from './Comunes'
import { EnjambreEtapas } from './Graficos'
import { useUnidad } from '../lib/unidad'
import { INST_MAP, INSTRUMENTOS, LINEAS, STAGES5 } from '../lib/data'
import {
  CATEGORIAS, DIMENSION, FAMILIAS, N_INS, N_LIN, TEXTO_ETAPA, VALORES, contarInstrumentos, corto, defFinalidad, defMecanismo,
  familiaIns, lista, pct, plural, uniq,
} from '../lib/sistema'

const nombreInst = (k) => (INST_MAP[k].nombre.startsWith(INST_MAP[k].sigla) ? INST_MAP[k].nombre : `${INST_MAP[k].sigla} · ${INST_MAP[k].nombre}`)
const puntosDe = (ins, fam = familiaIns) => [...ins].sort((a, b) => FAMILIAS.indexOf(fam(a)) - FAMILIAS.indexOf(fam(b))).map((i) => fam(i).c)

/* ---------------------------------------------------------------- cómo leer */
export function ComoLeer() {
  return (
    <section className="cu-leer" id="comprender" aria-labelledby="leer-t">
      <div className="cu-contenedor">
        <p className="pf-antetitulo"><span aria-hidden="true" />Antes de empezar</p>
        <h2 id="leer-t" className="cu-h2">Tres dimensiones para leer la oferta</h2>
        <p className="cu-lead">
          El recorrido parte de quién apoya —la institución— y clasifica la oferta en tres dimensiones: necesidades empresariales,
          mecanismos y tipos de apoyo, y etapas de desarrollo. Cada una responde una pregunta distinta: no son sinónimos.
        </p>
        <div className="cu-dims">
          {[
            ['01', 'Institución', '¿Quién apoya?', 'La agencia, ministerio o instituto que gestiona el instrumento.'],
            ['02', DIMENSION.finalidad.nombre, DIMENSION.finalidad.pregunta, DIMENSION.finalidad.def],
            ['03', 'Mecanismo y tipo de apoyo', '¿Cómo lo hace?', `${DIMENSION.mecanismo.def} ${DIMENSION.apoyo.def}`],
            ['04', 'Etapa de desarrollo', DIMENSION.etapa.pregunta, DIMENSION.etapa.def],
          ].map(([n, t, p, d], k) => (
            <motion.div key={n} className="cu-dim" initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, ease, delay: k * 0.08 }}>
              <b>{t}</b>
              <p>{d}</p>
            </motion.div>
          ))}
        </div>
        <p className="cu-unidades">
          <b>Instrumento</b>: intervención pública con identidad propia ({N_INS}). <b>Línea de apoyo</b>: cada modalidad operativa de
          un instrumento, con su público, prestación y condiciones ({N_LIN}). Salvo que se indique lo contrario, los gráficos cuentan
          instrumentos. Los colores representan siempre las mismas cinco familias de mecanismo.
        </p>
        <Familias />
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- 1. quiénes apoyan */
export function Quienes({ onOpen }) {
  const [sel, setSel] = useState(null)
  const U = useUnidad()
  const filas = U.contar('institucion')
  const top3 = filas.slice(0, 3)
  const n3 = top3.reduce((s, f) => s + f.n, 0)
  const elegida = sel && filas.find((f) => f.k === sel)
  return (
    <>
      <Capitulo
        id="quienes"
        antetitulo="Instituciones"
        titulo="Quiénes apoyan"
        texto={
          <>
            El sistema reúne <b>{filas.length} instituciones</b> que gestionan {N_INS} instrumentos de apoyo empresarial. Cada una tiene una
            cartera propia, que refleja su mandato: desarrollo empresarial, investigación e innovación, industria, cooperativismo,
            empleo, tecnología, promoción de exportaciones o investigación agropecuaria.
          </>
        }
        nota="La cantidad de instrumentos describe la amplitud de cada cartera; no indica presupuesto, cobertura ni impacto."
        indice={[[1, 'Instrumentos por institución', 'g1']]}
      />
      <Grafico
        id="g1"
        num={1}
        titulo={`${lista(top3.map((f) => INST_MAP[f.k].sigla))} gestionan el ${pct(n3, U.N)} % de ${U.los}`}
        bajada={`${U.Plur} por institución responsable y familia de mecanismo de cada ${U.sing}.`}
        pasos={[
          `${U.cuantos} gestiona cada institución y qué parte del total representan.`,
          <>El largo del tallo y el área del círculo indican la cantidad. A la derecha, un punto por {U.sing} con el color de su familia de mecanismo{U.id === 'ins' ? ' predominante' : ''}. Pulse una institución para ver {U.id === 'ins' ? 'sus instrumentos' : 'sus líneas'}.</>,
          <>
            <b>{INST_MAP[filas[0].k].sigla}</b> tiene la cartera más amplia ({filas[0].n}) y {INST_MAP[filas.at(-1).k].sigla} la más acotada ({filas.at(-1).n}).
            Las carteras se componen distinto: en {INST_MAP[filas[1].k].sigla} predomina {familiaDominante(filas[1].ins, U.fam).toLowerCase()}, y en{' '}
            {INST_MAP[filas[3].k].sigla}, {familiaDominante(filas[3].ins, U.fam).toLowerCase()}.
          </>,
        ]}
        tabla={{ cab: ['Institución', U.Plur, '% del total'], filas: filas.map((f) => [INST_MAP[f.k].nombre, f.n, pct(f.n, U.N)]) }}
        csv={`${U.plur.replace(/ /g, '_')}_por_institucion`}
        nota="Los programas interinstitucionales se cuentan una vez, en la institución que los registra."
      >
        <Lollipops
          filas={filas.map((f) => ({ k: f.k, n: f.n, ins: f.ins, label: nombreInst(f.k), title: INST_MAP[f.k].rol }))}
          base={U.N}
          unidad={U.plur}
          sel={sel}
          onPick={setSel}
          puntos={(f) => puntosDe(f.ins, U.fam)}
        />
        <ListaInstrumentos ins={elegida?.ins} titulo={elegida ? INST_MAP[elegida.k].nombre : ''} detalle={elegida ? INST_MAP[elegida.k].rol : ''} onOpen={onOpen} onCerrar={() => setSel(null)} />
      </Grafico>
    </>
  )
}
const familiaDominante = (ins, fam = familiaIns) => {
  const c = new Map()
  ins.forEach((i) => c.set(fam(i).n, (c.get(fam(i).n) || 0) + 1))
  return [...c.entries()].sort((a, b) => b[1] - a[1])[0][0]
}

/* ---------------------------------------------------------------- 2. qué buscan promover */
export function QuePromueven({ onOpen }) {
  const [sel, setSel] = useState(null)
  const U = useUnidad()
  const filas = U.contar('finalidad')
  const suma = filas.reduce((s, f) => s + f.n, 0)
  const varias = U.items.filter((i) => U.VAL.finalidad(i).length > 1).length
  const top = filas.slice(0, 3)
  const bajas = filas.filter((f) => f.n <= 4)
  const instPor = (f) => uniq(f.ins.map((i) => i.institucion)).length
  const amplia = [...filas].sort((a, b) => instPor(b) - instPor(a))[0]
  const elegida = sel && filas.find((f) => f.k === sel)
  return (
    <>
      <Capitulo
        id="finalidades"
        antetitulo="Necesidades empresariales"
        titulo="Qué buscan promover"
        texto={<>{DIMENSION.finalidad.def} Las finalidades describen el resultado buscado; no dicen todavía cómo se apoya ni en qué momento.</>}
        indice={[[2, 'Instrumentos por necesidad', 'g2']]}
      />
      <Grafico
        id="g2"
        num={2}
        titulo={`${corto(top[0].k)} es la necesidad más frecuente: ${top[0].n} de ${U.N} ${U.plur} la persiguen`}
        bajada={U.id === 'ins' ? 'Instrumentos por necesidad de sus líneas de apoyo.' : 'Líneas de apoyo por necesidad (cada línea tiene una sola).'}
        pasos={[
          U.id === 'ins'
            ? 'Cuántos instrumentos persiguen cada necesidad. Un instrumento cuenta en cada necesidad de alguna de sus líneas.'
            : 'Cuántas líneas de apoyo persiguen cada necesidad. Cada línea cuenta una sola vez.',
          U.id === 'ins' ? (
            <>Pase el cursor sobre una necesidad para leer su definición y púlsela para ver los instrumentos. Las barras suman {suma}, más que {U.N}: {varias} instrumentos tienen líneas con distintas necesidades.</>
          ) : (
            <>Pase el cursor sobre una necesidad para leer su definición y púlsela para ver las líneas. Las barras suman {suma}, el total de líneas de apoyo.</>
          ),
          <>
            {lista(top.map((f) => `${corto(f.k).toLowerCase()} (${f.n})`))} concentran la mayor parte de la oferta.
            {bajas.length > 0 && <> Con cuatro {U.plur} o menos aparecen {lista(bajas.map((f) => corto(f.k).toLowerCase()))}.</>}{' '}
            {corto(amplia.k)} es la necesidad en la que participan más instituciones ({instPor(amplia)}).
          </>,
        ]}
        tabla={{ cab: ['Necesidad', U.Plur, '% del total', 'Instituciones'], filas: filas.map((f) => [f.k, f.n, pct(f.n, U.N), instPor(f)]) }}
        csv={`${U.plur.replace(/ /g, '_')}_por_necesidad`}
        nota="Una cantidad menor de instrumentos no indica, por sí sola, una necesidad desatendida."
      >
        <Lollipops filas={filas.map((f) => ({ k: f.k, n: f.n, label: corto(f.k), title: defFinalidad(f.k) }))} base={U.N} unidad={U.plur} sel={sel} onPick={setSel} puntos={(f) => puntosDe(filas.find((x) => x.k === f.k).ins, U.fam)} />
        <ListaInstrumentos ins={elegida?.ins} titulo={elegida?.k || ''} detalle={elegida ? defFinalidad(elegida.k) : ''} onOpen={onOpen} onCerrar={() => setSel(null)} />
      </Grafico>
    </>
  )
}

/* ---------------------------------------------------------------- 3. cómo lo hacen */
export function ComoLoHacen({ onOpen }) {
  const [sel, setSel] = useState(null)
  const [selApoyo, setSelApoyo] = useState(null)
  const [todos, setTodos] = useState(false)
  const U = useUnidad()
  const mecs = U.contar('mecanismo')
  const apoyos = U.contar('apoyo')
  const fins = CATEGORIAS.finalidad
  const celda = useMemo(() => {
    const cache = new Map()
    return (f, m) => {
      const k = f + '|' + m
      if (!cache.has(k))
        cache.set(k, U.id === 'ins' ? INSTRUMENTOS.filter((i) => i.lineas.some((l) => l.finalidad === f && l.mecanismo === m)) : LINEAS.filter((l) => l.finalidad === f && l.mecanismo === m))
      return cache.get(k)
    }
  }, [U.id])
  const nMec = (f) => mecs.filter((m) => celda(f, m.k).length).length
  const unSolo = fins.filter((f) => nMec(f) === 1)
  const variada = [...fins].sort((a, b) => nMec(b) - nMec(a))[0]
  const llenas = fins.reduce((s, f) => s + nMec(f), 0)
  const ap = selApoyo && apoyos.find((a) => a.k === selApoyo)
  return (
    <>
      <Capitulo
        id="como"
        antetitulo="Mecanismos y tipos de apoyo"
        titulo="Cómo lo hacen"
        texto={
          <>
            Para entender cómo se apoya hay que distinguir dos cosas. El <b>mecanismo</b> es la forma en que se canaliza el apoyo; el{' '}
            <b>tipo de apoyo</b> es lo que la empresa recibe concretamente. Un mismo mecanismo —por ejemplo, un subsidio— puede financiar
            distintos tipos de apoyo, como una consultoría o un equipamiento.
          </>
        }
        indice={[[3, 'Necesidad y mecanismo', 'g3'], [4, 'Tipos de apoyo', 'g4']]}
      />
      <Grafico
        id="g3"
        num={3}
        titulo={`Dos mecanismos predominan: ${corto(mecs[0].k).toLowerCase()} (${mecs[0].n}) y ${corto(mecs[1].k).toLowerCase()} (${mecs[1].n} ${U.plur})`}
        bajada={U.id === 'ins' ? 'Instrumentos según la necesidad y el mecanismo de sus líneas.' : 'Líneas de apoyo según su necesidad y su mecanismo.'}
        pasos={[
          U.id === 'ins'
            ? 'Cada fila es una necesidad y cada columna un mecanismo. Cada celda indica cuántos instrumentos tienen al menos una línea con esa combinación.'
            : 'Cada fila es una necesidad y cada columna un mecanismo. Cada celda indica cuántas líneas de apoyo tienen esa combinación.',
          `Cuanto más oscura la celda, más ${U.plur}; una celda vacía indica que no hay registros con esa combinación. Pulse una columna para ordenar y una celda para ver el detalle.`,
          <>
            Solo {llenas} de las {fins.length * mecs.length} combinaciones tienen oferta. {corto(variada)} es la necesidad que se atiende con más
            mecanismos ({nMec(variada)}).
            {unSolo.length > 0 && <> {lista(unSolo.map((f) => corto(f)))} se {unSolo.length > 1 ? 'atienden' : 'atiende'} con un solo mecanismo.</>}
          </>,
        ]}
        tabla={{ cab: ['Necesidad', ...mecs.map((m) => m.k)], filas: fins.map((f) => [f, ...mecs.map((m) => celda(f, m.k).length)]) }}
        csv={`necesidad_por_mecanismo_${U.id === 'ins' ? 'instrumentos' : 'lineas'}`}
        nota="Coincidir en una combinación no implica duplicación: los instrumentos pueden diferir en público, prestación y condiciones."
      >
        <MatrizPuntos
          filas={fins.map((f) => ({ k: f, label: corto(f), title: defFinalidad(f) }))}
          cols={mecs.map((m) => ({ k: m.k, label: corto(m.k), title: defMecanismo(m.k) }))}
          celda={celda}
          sel={sel}
          onPick={setSel}
          etiquetaFilas="Necesidad"
          etiquetaCols="Mecanismo"
        />
        <LeyendaPuntos modo="n" />
        <ListaInstrumentos ins={sel && celda(sel[0], sel[1])} titulo={sel ? `${corto(sel[0])} · ${corto(sel[1])}` : ''} onOpen={onOpen} onCerrar={() => setSel(null)} />
      </Grafico>
      <Grafico
        id="g4"
        num={4}
        titulo={`Lo que más reciben las empresas: ${apoyos[0].k.toLowerCase()} y ${apoyos[1].k.toLowerCase()}`}
        bajada={`${U.Plur} que ofrecen cada tipo de apoyo.`}
        pasos={[
          `Qué prestaciones concretas ofrecen ${U.id === 'ins' ? 'los instrumentos' : 'las líneas de apoyo'}: hay ${apoyos.length} tipos de apoyo registrados.`,
          `${U.id === 'ins' ? 'Un instrumento' : 'Una línea'} puede ofrecer varios tipos de apoyo, por lo que las sumas superan ${U.N}. Pulse un tipo para ver ${U.id === 'ins' ? 'los instrumentos' : 'las líneas'}.`,
          <>
            Los más frecuentes son {lista(apoyos.slice(0, 3).map((a) => `${a.k.toLowerCase()} (${a.n})`))}. Mecanismos como{' '}
            {lista(mecs.filter((m) => m.n <= 2).map((m) => corto(m.k).toLowerCase()))} aparecen en {U.pocos}.
          </>,
        ]}
        tabla={{ cab: ['Tipo de apoyo', U.Plur, '% del total'], filas: apoyos.map((a) => [a.k, a.n, pct(a.n, U.N)]) }}
        csv={`${U.plur.replace(/ /g, '_')}_por_tipo_de_apoyo`}
      >
        <Lollipops filas={(todos ? apoyos : apoyos.slice(0, 12)).map((a) => ({ k: a.k, n: a.n, label: a.k }))} base={U.N} unidad={U.plur} sel={selApoyo} onPick={setSelApoyo} />
        <button className="cu-enlace" onClick={() => setTodos((t) => !t)}>
          {todos ? 'Mostrar los 12 más frecuentes' : `Ver los ${apoyos.length} tipos de apoyo`}
        </button>
        <ListaInstrumentos ins={ap?.ins} titulo={ap?.k || ''} onOpen={onOpen} onCerrar={() => setSelApoyo(null)} />
      </Grafico>
    </>
  )
}

/* ---------------------------------------------------------------- 4. en qué momento */
export function EnQueMomento({ onOpen }) {
  const [foco, setFoco] = useState(null)
  const [sel, setSel] = useState('consolidacion')
  const U = useUnidad()
  const principal = (e) => U.items.filter((i) => U.etapaPrincipal(i) === e)
  const cobertura = (e) => (e === 'transversal' ? principal(e) : U.items.filter((i) => U.cubre(i, e)))
  const cons = principal('consolidacion').length
  const temp = ['ideacion', 'id', 'marcha'].reduce((s, e) => s + principal(e).length, 0)
  const multi = U.items.filter(U.multi).length
  const trans = principal('transversal').length
  const actual = cobertura(sel)
  const top = (dim) => U.contar(dim, actual).slice(0, 3)
  const nombre = (e) => (e === 'transversal' ? 'Transversal' : STAGES5.find((s) => s.id === e).nombre)
  return (
    <>
      <Capitulo
        id="momento"
        antetitulo="Etapas de desarrollo"
        titulo="En qué momento intervienen"
        texto={
          <>
            La clasificación por etapas permite identificar los distintos tipos de apoyo que ofrecen los instrumentos, las instituciones que
            intervienen y las referencias expertas utilizadas para definirlos. Es importante aclarar que estas etapas no representan el ciclo
            de vida, la antigüedad ni el grado de madurez de una empresa, sino el tipo de actividad, necesidad o proyecto al que se orienta
            el apoyo. Por ejemplo, una empresa consolidada puede acceder a un instrumento clasificado en la etapa de desarrollo si busca
            financiamiento para realizar un proyecto de I+D o incorporar una nueva tecnología.
          </>
        }
        indice={[[5, 'Instrumentos por etapa', 'g5']]}
      />
      <Grafico
        id="g5"
        num={5}
        titulo={`La oferta se concentra en la consolidación: ${cons} de ${U.N} ${U.plur} tienen allí su etapa principal`}
        bajada={U.id === 'ins' ? 'Un punto por instrumento en su etapa principal; los arcos señalan otras etapas que cubren sus líneas.' : 'Un punto por línea de apoyo en su etapa principal; los arcos señalan otras etapas que también cubre.'}
        pasos={[
          'Dónde se ubica cada instrumento a lo largo de las etapas del proceso que recibe apoyo, y cuáles alcanzan más de una etapa.',
          U.id === 'ins'
            ? 'Cada punto es un instrumento: el tamaño crece con sus líneas y el color indica su familia de mecanismo. Los arcos parten del instrumento hacia otra etapa que cubre alguna de sus líneas. Pase el cursor para identificarlo; pulse para abrir su ficha.'
            : 'Cada punto es una línea de apoyo: el tamaño crece con sus tipos de apoyo y el color indica su familia de mecanismo. Los arcos parten de la línea hacia otra etapa que también cubre. Pase el cursor para identificarla; pulse para abrir la ficha de su instrumento.',
          <>
            Las tres primeras etapas reúnen {temp} {U.plur} como etapa principal, frente a {cons} en consolidación.{' '}
            {plural(multi, `${U.sing} cubre`, `${U.plur} cubren`)} más de una etapa y {trans} {trans === 1 ? 'es transversal' : 'son transversales'}:
            acompañan a empresas en distintos momentos.
          </>,
        ]}
        tabla={{
          cab: ['Etapa', `${U.Plur} (etapa principal)`, U.id === 'ins' ? 'Instrumentos con alguna línea en la etapa' : 'Líneas que cubren la etapa'],
          filas: [...STAGES5.map((e) => e.id), 'transversal'].map((e) => [nombre(e), principal(e).length, cobertura(e).length]),
        }}
        csv={`${U.plur.replace(/ /g, '_')}_por_etapa`}
        nota="El número de cada etapa cuenta instrumentos con esa etapa como principal (una sola vez). Los arcos no se suman."
      >
        <Familias foco={foco} setFoco={setFoco} conteo={(f) => U.items.filter((i) => U.fam(i) === f).length} />
        <EnjambreEtapas onOpen={onOpen} foco={foco} U={U} />
        <div className="cu-etapa-tabs" role="tablist" aria-label="Detalle por etapa">
          {[...STAGES5.map((e) => e.id), 'transversal'].map((e) => (
            <button key={e} role="tab" aria-selected={sel === e} className={sel === e ? 'on' : ''} onClick={() => setSel(e)}>
              {nombre(e)}
            </button>
          ))}
        </div>
        <AnimatePresence mode="wait">
          <motion.div key={sel} className="cu-etapa-detalle" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.3, ease }}>
            <div>
              <p className="cu-eyebrow">{nombre(sel)}</p>
              <p>{TEXTO_ETAPA[sel]}</p>
              <small>{plural(actual.length, `${U.sing} la tiene`, `${U.plur} la tienen`)} como etapa principal{U.id === 'ins' ? ' o con alguna línea' : ' o la cubre'}.</small>
            </div>
            {[
              ['Qué se promueve', 'finalidad', (k) => corto(k)],
              ['Con qué mecanismo', 'mecanismo', (k) => corto(k)],
              ['Quién interviene', 'institucion', (k) => INST_MAP[k].sigla],
            ].map(([t, dim, et]) => (
              <div key={dim}>
                <p className="cu-eyebrow">{t}</p>
                <ol className="cu-top">
                  {top(dim).map((x) => (
                    <li key={x.k}>
                      <span>{et(x.k)}</span>
                      <b>{x.n}</b>
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
      </Grafico>
    </>
  )
}

/* ---------------------------------------------------------------- síntesis */
export function Sintesis() {
  const inst = contarInstrumentos('institucion')
  const fin = contarInstrumentos('finalidad')
  const mec = contarInstrumentos('mecanismo')
  const cons = INSTRUMENTOS.filter((i) => i.etapa === 'consolidacion').length
  const items = [
    ['Quién', `${inst.length} instituciones gestionan ${N_INS} instrumentos; ${INST_MAP[inst[0].k].sigla}, ${INST_MAP[inst[1].k].sigla} y ${INST_MAP[inst[2].k].sigla} tienen las carteras más amplias.`],
    ['Qué', `${corto(fin[0].k)}, ${corto(fin[1].k).toLowerCase()} y ${corto(fin[2].k).toLowerCase()} son las necesidades con más instrumentos.`],
    ['Cómo', `${corto(mec[0].k)} y ${corto(mec[1].k).toLowerCase()} son los mecanismos más usados; lo que reciben las empresas va de la asistencia técnica al financiamiento de proyectos.`],
    ['Cuándo', `${pct(cons, N_INS)} % de los instrumentos tiene su etapa principal en la consolidación de empresas en operación.`],
  ]
  return (
    <section className="cu-sintesis" aria-labelledby="sintesis-t">
      <div className="cu-contenedor">
        <p className="cu-eyebrow">En síntesis</p>
        <h2 id="sintesis-t">¿Quién apoya qué, y en qué momento?</h2>
        <div className="cu-sintesis-grid">
          {items.map(([t, p], k) => (
            <motion.div key={t} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: k * 0.08, ease }}>
              <b>{t}</b>
              <p>{p}</p>
            </motion.div>
          ))}
        </div>
        <div className="cu-botones">
          <a className="cu-boton claro" href="#explorar">Consultar la oferta</a>
          <a className="cu-boton contorno" href="#instituciones">Analizar las instituciones</a>
        </div>
      </div>
    </section>
  )
}
