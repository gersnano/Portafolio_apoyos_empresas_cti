// Parte 3 · Analizar las instituciones: matrices institución × dimensión, cantidad o composición de la cartera.
import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Reveal, Tabs, ease } from './motion'
import { LeyendaPuntos, ListaInstrumentos, MatrizPuntos } from './Comunes'
import { Ico } from './Marcas'
import { ETAPAS, INST_MAP, INSTITUCIONES, INSTRUMENTOS, LINEAS, STAGES5 } from '../lib/data'
import { UNIDADES, useUnidad } from '../lib/unidad'
import { CATEGORIAS, DIMENSION, N_INS, VALORES, contarInstrumentos, corto, defFinalidad, defMecanismo, etiqueta, lista, pct, plural } from '../lib/sistema'

const MODOS = [
  { id: 'n', label: 'Cantidad de instrumentos' },
  { id: 'pct', label: '% de la cartera' },
]
// una sola matriz: institución × la dimensión elegida
const DIMS = [
  { id: 'finalidad', label: 'Necesidad empresarial', titulo: 'Institución × necesidad empresarial: qué atiende cada institución' },
  { id: 'mecanismo', label: 'Mecanismo', titulo: 'Institución × mecanismo: cómo canaliza sus apoyos' },
  { id: 'etapa', label: 'Etapa', titulo: 'Institución × etapa: en qué momentos interviene', nota: 'La distribución de los instrumentos muestra una mayor concentración de la oferta en el apoyo a empresas en funcionamiento y procesos de consolidación, mientras que las etapas tempranas y las actividades de I+D presentan una menor participación de instrumentos e instituciones. La selección en la matriz permite explorar en detalle la composición de la oferta para cada categoría.', nota2: 'Cuenta instrumentos con la etapa como principal o con alguna línea en ella; los transversales, en su columna.' },
]
const nombreEtapa = (e) => (e === 'transversal' ? 'Transversal' : ETAPAS.find((x) => x.id === e)?.nombre)

export default function Instituciones({ onOpen, foco }) {
  const [elegidas, setElegidas] = useState(INSTITUCIONES.map((i) => i.id))
  const [modo, setModo] = useState('n')
  const [dim, setDim] = useState('finalidad')
  const [sel, setSel] = useState(null) // { dim, fila, col }
  useEffect(() => {
    if (foco?.id) {
      setElegidas([foco.id])
      setSel(null)
    }
  }, [foco])
  const U = useUnidad()
  const cartera = (inst) => INSTRUMENTOS.filter((i) => i.institucion === inst)
  // la matriz cuenta en la unidad elegida (instrumentos o líneas de apoyo)
  const carteraU = (inst) => U.items.filter((i) => i.institucion === inst)
  const celdaDe = (dim) => (inst, cat) => carteraU(inst).filter((i) => U.VAL[dim](i).includes(cat))
  const filas = elegidas.map((k) => ({ k, label: INST_MAP[k].sigla, sub: plural(carteraU(k).length, U.sing, U.plur), title: INST_MAP[k].nombre }))
  const alternar = (k) => {
    setSel(null)
    setElegidas((e) => (e.includes(k) ? (e.length > 1 ? e.filter((x) => x !== k) : e) : INSTITUCIONES.map((i) => i.id).filter((x) => e.includes(x) || x === k)))
  }
  const solo = (k) => {
    setSel(null)
    setElegidas([k])
  }
  const colsApoyo = useMemo(() => {
    const cuenta = contarInstrumentos('apoyo', INSTRUMENTOS.filter((i) => elegidas.includes(i.institucion)))
    return cuenta.slice(0, 14).map((a) => a.k)
  }, [elegidas])
  const COLS = {
    finalidad: CATEGORIAS.finalidad.map((f) => ({ k: f, label: corto(f), title: defFinalidad(f) })),
    mecanismo: CATEGORIAS.mecanismo.map((m) => ({ k: m, label: corto(m), title: defMecanismo(m) })),
    apoyo: colsApoyo.map((a) => ({ k: a, label: a })),
    etapa: CATEGORIAS.etapa.map((e) => ({ k: e, label: nombreEtapa(e) })),
  }
  const elegidaLista = sel && celdaDe(sel.dim)(sel.fila, sel.col)
  const bloque = (dim, titulo, nota, nota2) => (
    <div className="cu-inst-bloque">
      <h3 className="cu-h3">{titulo}</h3>
      {nota && <p className="cu-inst-lectura">{nota}</p>}
      {nota2 && <p className="cu-nota">{nota2}</p>}
      <MatrizPuntos
        filas={filas}
        cols={COLS[dim]}
        celda={celdaDe(dim)}
        modo={modo}
        baseFila={(k) => carteraU(k).length}
        sel={sel && sel.dim === dim ? [sel.fila, sel.col] : null}
        onPick={(p) => setSel(p ? { dim, fila: p[0], col: p[1] } : null)}
        etiquetaFilas="Institución"
        etiquetaCols={DIMENSION[dim]?.nombre || 'Etapa'}
        trasponer
        ordenNatural={dim === 'etapa'}
      />
      {sel && sel.dim === dim && (
        <ListaInstrumentos
          ins={elegidaLista}
          titulo={`${INST_MAP[sel.fila].sigla} · ${etiqueta(dim, sel.col)}`}
          detalle={`${pct(elegidaLista.length, carteraU(sel.fila).length)} % de su cartera`}
          onOpen={onOpen}
          onCerrar={() => setSel(null)}
        />
      )}
    </div>
  )

  // perfil comparable de cada cartera
  const perfil = (k) => {
    const c = cartera(k)
    const top = (dim) => contarInstrumentos(dim, c)[0]
    const tf = top('finalidad')
    const tm = top('mecanismo')
    const te = contarInstrumentos('etapaPrincipal', c)[0]
    return {
      k,
      n: c.length,
      lineas: LINEAS.filter((l) => l.institucion === k).length,
      fins: contarInstrumentos('finalidad', c).length,
      mecs: contarInstrumentos('mecanismo', c).length,
      tf,
      tm,
      te,
    }
  }
  const perfiles = elegidas.map(perfil)
  // coincidencias y complementariedades (descriptivas)
  const finsDe = (k) => new Set(cartera(k).flatMap(VALORES.finalidad))
  const comunes = elegidas.length > 1 ? CATEGORIAS.finalidad.filter((f) => elegidas.every((k) => finsDe(k).has(f))) : []
  const exclusivas = elegidas.length > 1
    ? CATEGORIAS.finalidad
        .map((f) => [f, elegidas.filter((k) => finsDe(k).has(f))])
        .filter(([, ks]) => ks.length === 1)
    : []

  return (
    <section className="cu-herramienta alt" id="instituciones" aria-labelledby="inst-t">
      <div className="cu-contenedor">
        <Reveal className="cu-herr-cab">
          <p className="pf-antetitulo"><span aria-hidden="true" />Analizar las instituciones</p>
          <h2 id="inst-t" className="cu-h2">¿Qué lugar ocupa cada institución dentro del sistema de apoyos?<span className="cu-punto" /></h2>
          <p className="cu-lead">
            Seleccione una institución para ver su perfil o varias para compararlas. Las matrices muestran qué necesidades
            atienden, con qué mecanismos y en qué etapas intervienen. Pulse una celda para ver los
            instrumentos que explican ese resultado.
          </p>
        </Reveal>

        <div className="cu-inst-sel" role="group" aria-label="Instituciones seleccionadas">
          {INSTITUCIONES.map((i) => (
            <button key={i.id} className={elegidas.includes(i.id) ? 'on' : ''} aria-pressed={elegidas.includes(i.id)} onClick={() => alternar(i.id)} onDoubleClick={() => solo(i.id)} title={`${i.nombre}. Doble clic: ver solo esta institución`}>
              {i.sigla}
            </button>
          ))}
          <button className="cu-enlace" onClick={() => { setSel(null); setElegidas(INSTITUCIONES.map((i) => i.id)) }}>Todas</button>
          <span className="cu-nota" style={{ margin: 0 }}>Clic: agregar o quitar · doble clic: solo esa institución</span>
        </div>

        <div className="cu-inst-modo">
          <Tabs id="inst-unidad" items={UNIDADES} value={U.id} onChange={(v) => { U.setU(v); setSel(null) }} label="Unidad de conteo" />
          <Tabs id="inst-modo" items={MODOS} value={modo} onChange={setModo} label="Qué se muestra" />
        </div>
        <p className="cu-cuenta">
          {modo === 'n'
            ? U.id === 'ins'
              ? 'Cantidad: instrumentos de la institución con al menos una línea en esa categoría.'
              : 'Cantidad: líneas de apoyo de la institución en esa categoría.'
            : `Porcentaje de la cartera: qué parte de ${U.id === 'ins' ? 'los instrumentos' : 'las líneas de apoyo'} de cada institución está en esa categoría. Permite comparar carteras de distinto tamaño.`}{' '}
          {U.id === 'ins' ? 'Un instrumento puede estar en varias categorías, por lo que cada columna puede sumar más que su total.' : 'Una línea puede cubrir varias etapas.'} La cantidad de{' '}
          {U.plur} no indica presupuesto, cobertura, efectividad ni impacto.
        </p>

        <div className="cu-perfiles">
          <table className="cu-perfil-tabla">
            <caption>Composición de cada cartera</caption>
            <thead>
              <tr>
                <th scope="col">Institución</th>
                <th scope="col">Instrumentos</th>
                <th scope="col">Líneas</th>
                <th scope="col">Necesidades</th>
                <th scope="col">Necesidad más frecuente</th>
                <th scope="col">Mecanismo más frecuente</th>
                <th scope="col">Etapa principal más frecuente</th>
              </tr>
            </thead>
            <tbody>
              {perfiles.map((p) => (
                <motion.tr key={p.k} layout transition={{ duration: 0.3, ease }}>
                  <th scope="row" title={INST_MAP[p.k].nombre}>{INST_MAP[p.k].sigla}</th>
                  <td>{p.n} <small>({pct(p.n, N_INS)} % del sistema)</small></td>
                  <td>{p.lineas}</td>
                  <td>{p.fins} de {CATEGORIAS.finalidad.length}</td>
                  <td>{corto(p.tf.k)} <small>{pct(p.tf.n, p.n)} %</small></td>
                  <td>{corto(p.tm.k)} <small>{pct(p.tm.n, p.n)} %</small></td>
                  <td>{nombreEtapa(p.te.k)} <small>{pct(p.te.n, p.n)} %</small></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        <AnimatePresence>
          {elegidas.length > 1 && elegidas.length < INSTITUCIONES.length && (
            <motion.div className="cu-conclusion" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <span>Coincidencias y complementariedades entre las seleccionadas</span>
              <p>
                {comunes.length
                  ? <>Todas tienen instrumentos en {lista(comunes.map((f) => corto(f).toLowerCase()))}.</>
                  : <>No hay una necesidad en la que tengan instrumentos todas a la vez.</>}{' '}
                {exclusivas.length > 0 && (
                  <>Solo una de ellas atiende {lista(exclusivas.map(([f, ks]) => `${corto(f).toLowerCase()} (${INST_MAP[ks[0]].sigla})`))}.</>
                )}{' '}
                Coincidir en una necesidad no implica duplicación: los instrumentos pueden diferir en público, prestación y condiciones.
              </p>
            </motion.div>
          )}
          {elegidas.length === 1 && (
            <motion.div className="cu-conclusion" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <span>{INST_MAP[elegidas[0]].nombre}</span>
              <p>
                {INST_MAP[elegidas[0]].rol}. Su cartera reúne {plural(perfiles[0].n, 'instrumento', 'instrumentos')} y{' '}
                {plural(perfiles[0].lineas, 'línea de apoyo', 'líneas de apoyo')}; atiende {perfiles[0].fins} de las{' '}
                {CATEGORIAS.finalidad.length} finalidades con {plural(perfiles[0].mecs, 'mecanismo', 'mecanismos')}. Su finalidad más
                frecuente es {corto(perfiles[0].tf.k).toLowerCase()} ({pct(perfiles[0].tf.n, perfiles[0].n)} % de su cartera).
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="cu-inst-dim">
          <span className="cu-inst-dim-et">Cruzar las instituciones con</span>
          <Tabs id="inst-dim" items={DIMS} value={dim} onChange={(v) => { setDim(v); setSel(null) }} label="Dimensión" />
        </div>
        <AnimatePresence mode="wait">
          <motion.div key={dim} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3, ease }}>
            {(() => {
              const d = DIMS.find((x) => x.id === dim)
              return bloque(d.id, d.titulo, d.nota, d.nota2)
            })()}
          </motion.div>
        </AnimatePresence>
        <LeyendaPuntos modo={modo} />
      </div>
    </section>
  )
}

export { STAGES5 }
