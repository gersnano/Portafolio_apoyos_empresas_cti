// Parte 2 · Explorar los instrumentos: búsqueda, filtros combinables y resultados.
import { useDeferredValue, useMemo, useState } from 'react'
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion'
import Icon from './Icon'
import { Reveal, ease } from './motion'
import { Ico } from './Marcas'
import { INST_MAP, INSTITUCIONES, STAGES5 } from '../lib/data'
import { CATEGORIAS, DIMENSION, VALORES, corto, descripcion, etiqueta, filtrarOferta, plural } from '../lib/sistema'

export const FILTROS = { q: '', institucion: '', finalidad: '', mecanismo: '', apoyo: '', etapa: '' }
const CAMPOS = [
  ['institucion', 'Institución', () => INSTITUCIONES.map((i) => [i.id, i.nombre.startsWith(i.sigla) ? i.nombre : `${i.sigla} · ${i.nombre}`])],
  ['finalidad', 'Finalidad', () => CATEGORIAS.finalidad.map((f) => [f, corto(f)])],
  ['mecanismo', 'Mecanismo', () => CATEGORIAS.mecanismo.map((m) => [m, corto(m)])],
  ['apoyo', 'Tipo de apoyo', () => CATEGORIAS.apoyo.map((a) => [a, a])],
  ['etapa', 'Etapa', () => [...STAGES5.map((e) => [e.id, `${e.orden}. ${e.nombre}`]), ['transversal', 'Transversal']]],
]
const PAGINA = 12
const AYUDA = {
  finalidad: DIMENSION.finalidad.def,
  mecanismo: DIMENSION.mecanismo.def,
  apoyo: DIMENSION.apoyo.def,
  etapa: DIMENSION.etapa.def,
}

export default function Explorar({ filtros, setFiltros, onOpen }) {
  const [limite, setLimite] = useState(PAGINA)
  const q = useDeferredValue(filtros.q)
  const res = useMemo(
    () => filtrarOferta({ ...filtros, q }).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')),
    [filtros, q],
  )
  const nLineas = res.reduce((s, r) => s + r.match.length, 0)
  const activos = Object.entries(filtros).filter(([, v]) => v)
  const set = (k, v) => {
    setFiltros((f) => ({ ...f, [k]: v }))
    setLimite(PAGINA)
  }
  return (
    <section className="cu-herramienta" id="explorar" aria-labelledby="explorar-t">
      <div className="cu-contenedor">
        <Reveal className="cu-herr-cab">
          <p className="pf-parte"><Ico n="explorar" size={18} /> Parte 2 · Explorar los instrumentos</p>
          <h2 id="explorar-t" className="cu-h2">Encontrar los apoyos que le interesan<span className="cu-punto" /></h2>
          <p className="cu-lead">
            Busque por nombre o combine filtros. Un instrumento aparece cuando al menos una de sus líneas cumple todos los
            filtros elegidos a la vez; cada instrumento se cuenta una sola vez.
          </p>
        </Reveal>

        <div className="sx-filtros" role="search">
          <label className="sx-buscar">
            <Icon name="search" />
            <span className="sr-only">Buscar por nombre</span>
            <input
              type="search"
              placeholder="Buscar por nombre o tema (ej.: exportación, cooperativas, prototipo)"
              value={filtros.q}
              onChange={(e) => set('q', e.target.value)}
            />
          </label>
          <div className="sx-selects">
            {CAMPOS.map(([k, n, ops]) => (
              <label key={k} className={filtros[k] ? 'on' : ''} title={AYUDA[k]}>
                <span>{n}</span>
                <select value={filtros[k]} onChange={(e) => set(k, e.target.value)}>
                  <option value="">Todas</option>
                  {ops().map(([v, t]) => (
                    <option key={v} value={v}>{t}</option>
                  ))}
                </select>
              </label>
            ))}
          </div>
        </div>

        <div className="sx-estado" aria-live="polite">
          <p>
            <b>{plural(res.length, 'instrumento', 'instrumentos')}</b> · {plural(nLineas, 'línea de apoyo', 'líneas de apoyo')} que
            cumplen la selección
          </p>
          <div className="sx-activos">
            {activos.map(([k, v]) => (
              <button key={k} className="sx-activo" onClick={() => set(k, '')} aria-label={`Quitar filtro ${v}`}>
                {k === 'q' ? `“${v}”` : `${CAMPOS.find((c) => c[0] === k)[1]}: ${etiqueta(k, v)}`}
                <Icon name="x" size={13} />
              </button>
            ))}
            {activos.length > 0 && (
              <button className="cu-enlace" onClick={() => { setFiltros(FILTROS); setLimite(PAGINA) }}>
                Restablecer selección
              </button>
            )}
          </div>
        </div>

        {res.length === 0 ? (
          <div className="sx-vacio">
            <b>No hay instrumentos que cumplan todos los filtros a la vez.</b>
            <span>
              Esto describe el relevamiento, no necesariamente la ausencia de apoyos en el país. Pruebe quitando algún filtro.
            </span>
          </div>
        ) : (
          <LayoutGroup>
            <motion.div className="sx-resultados" layout>
              <AnimatePresence>
                {res.slice(0, limite).map((i, k) => (
                  <Tarjeta key={i.id} ins={i} onOpen={onOpen} k={k} />
                ))}
              </AnimatePresence>
            </motion.div>
          </LayoutGroup>
        )}
        {res.length > limite && (
          <div style={{ textAlign: 'center', marginTop: 20 }}>
            <button className="cu-boton contorno" onClick={() => setLimite((l) => l + PAGINA)}>
              Ver más ({res.length - limite} restantes)
            </button>
          </div>
        )}
      </div>
    </section>
  )
}

function Tarjeta({ ins, onOpen, k }) {
  const fins = VALORES.finalidad({ lineas: ins.match })
  const apoyos = VALORES.apoyo({ lineas: ins.match }).slice(0, 3)
  const etapa = ins.etapa === 'transversal' ? 'Transversal' : STAGES5.find((e) => e.id === ins.etapa)?.nombre
  return (
    <motion.button
      layout
      className="sx-tarjeta"
      onClick={() => onOpen(ins.id)}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.3, ease, delay: Math.min(k % PAGINA, 8) * 0.03 }}
    >
      <span className="sx-t-inst">
        <b>{INST_MAP[ins.institucion].sigla}</b> {INST_MAP[ins.institucion].nombre.startsWith(INST_MAP[ins.institucion].sigla) ? '' : INST_MAP[ins.institucion].nombre}
      </span>
      <h3>{ins.nombre}</h3>
      <p>{descripcion(ins)}</p>
      <dl>
        <dt>Para qué</dt>
        <dd>{fins.map(corto).join(' · ')}</dd>
        <dt>Qué ofrece</dt>
        <dd>{apoyos.join(' · ')}</dd>
        <dt>Etapa</dt>
        <dd>{etapa}</dd>
      </dl>
      <span className="sx-t-pie">
        {ins.lineas.length > 1 ? `${ins.match.length} de ${ins.lineas.length} líneas cumplen la selección` : '1 línea de apoyo'}
        <span>Ver ficha →</span>
      </span>
    </motion.button>
  )
}
