# Arquitectura de información · Portafolio de apoyo empresarial en CTI

Pregunta ordenadora: **¿Quién apoya qué, y en qué momento?**
Jerarquía: comprender el sistema → explorar los instrumentos → analizar las instituciones.

## Unidades y reglas de conteo
- Unidad principal: **instrumento** (83). Las **líneas de apoyo** (114) son modalidades de un instrumento.
- Un instrumento pertenece a una categoría si al menos una de sus líneas la tiene; las sumas por categoría pueden superar 83.
- Dimensiones distintas: **finalidad** (qué se promueve), **mecanismo** (cómo se canaliza), **tipo de apoyo** (qué recibe la empresa), **etapa** (en qué momento del proceso).
- El tipo de acceso no forma parte del relato ni de los filtros.

## Página
| Bloque | Pregunta | Visualización | Función |
|---|---|---|---|
| Portada | ¿Quién apoya qué, y en qué momento? | Camino en tres pasos | Orientar y fijar el alcance |
| Antes de empezar | ¿Cómo leer el sistema? | Cuatro tarjetas de dimensiones | Diferenciar las categorías |
| 1 · Quiénes apoyan | Instituciones | Barras ordenadas (cantidad y %) | Comparar carteras |
| 2 · Qué buscan promover | Finalidades | Barras ordenadas | Comparar finalidades |
| 3 · Cómo lo hacen | Mecanismos y tipos de apoyo | Matriz finalidad × mecanismo + barras de tipos de apoyo | Mostrar el cruce y lo que recibe la empresa |
| 4 · En qué momento | Etapas | Secuencia de etapas + detalle por etapa | Explicar los momentos de intervención |
| Síntesis | Respuesta a la pregunta | Cuatro conclusiones | Cerrar el relato |
| Parte 2 · Explorar | ¿Qué apoyos me sirven? | Búsqueda, 5 filtros, tarjetas, ficha | Consulta |
| Parte 3 · Instituciones | ¿Qué lugar ocupa cada institución? | Tabla de composición + matrices institución × finalidad, × mecanismo, × tipo de apoyo / etapa (cantidad o % de la cartera) | Comparar y bajar a los instrumentos |
| Metodología | Alcance y criterios | Texto | Transparencia |

Cada sección del relato: pregunta, título con el hallazgo, explicación, nota «qué se cuenta», visualización y conclusión calculada con los datos.

## Identidad visual (versión 18/11, revisada)
- Identidad propia del portafolio dentro de la familia UNE: marca de mosaico, DM Sans + Literata, acento verde azulado (#0f7c8c) sobre azul UNE, cabecera de una sola barra, riel de preguntas, «Figura N» con lectura en tres tarjetas (qué se cuenta · cómo se lee · lo que encontramos).
- Ciencia uruguaya se cita solo como otro producto de la UNE (enlace en el pie).
- Logos de las instituciones sin modificar: solo se recortan márgenes vacíos y se escalan proporcionalmente; el tamaño iguala el área visible de cada marca (src/assets/logos/logos.json). MIEM se muestra con su sigla hasta contar con el logo oficial.
- Visualizaciones con d3 (escalas, d3-force) y Framer Motion; una sola paleta categórica de cinco familias de mecanismo, con íconos propios.
